/*
 * ClaudeOS kernel - kmain
 *
 * Milestone 3 scope: keyboard input and a basic interactive shell.
 * Builds directly on Milestone 2's interrupt infrastructure - the
 * keyboard driver is just another IRQ handler registered the same way
 * the PIT's was.
 */

#include "vga.h"
#include "idt.h"
#include "isr.h"
#include "irq.h"
#include "pic.h"
#include "pit.h"
#include "keyboard.h"
#include "shell.h"
#include "pmm.h"
#include "kmalloc.h"

void kmain(void) {
    vga_clear();
    vga_print_at("ClaudeOS - Milestone 4: memory management", 0, 0);
    vga_print_at("Initializing...", 1, 0);

    idt_install();
    isr_install_all();
    pic_remap();
    irq_install_all();
    keyboard_init();

    __asm__ volatile ("sti");

    pit_init(100);

    pmm_init();
    kheap_init();

    term_clear();
    shell_run();

    /* shell_run() has an infinite command loop and should never
       return, but if it somehow does, don't fall off into garbage -
       halt cleanly. */
    for (;;) {
        __asm__ volatile ("cli; hlt");
    }
}
