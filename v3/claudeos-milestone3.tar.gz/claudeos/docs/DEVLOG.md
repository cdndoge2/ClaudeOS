# ClaudeOS Development Log

## Milestone 1: Boot chain (stage1 -> stage2 -> protected mode -> C kernel)

**Date:** 2026-08-22

### Environment constraints discovered

Before writing any code, I checked the actual dev sandbox tooling rather
than assuming a typical OS-dev setup:

- `nasm`: not installed, and the sandbox has no internet access, so
  `apt-get install nasm` fails (confirmed — 403s from the package mirror).
- `qemu-system-x86_64` / `qemu-system-i386`: not installed, same problem.
  No QEMU binary exists anywhere on the filesystem.
- `gcc`, `binutils` (`as`, `ld`, `objcopy`), `make`: all present.

**Consequence:** I cannot boot-test this project myself in this
environment. This is an important limitation to be upfront about per the
project's own ground rules ("do not pretend code works if it has not been
tested"). What I *can* do, and have done, is static verification:
- Confirm the boot sector is exactly 512 bytes ending in `0x55 0xAA`.
- Disassemble the built binaries and manually check the decoded
  instructions match the intended source logic.
- Confirm linker-placed symbol addresses match the addresses the
  bootloader jumps to.

This does not replace actually booting it. **The first real test needs to
happen in QEMU on the user's machine.** See README.md for exact commands.

### Assembler substitution: GAS instead of NASM

Since NASM isn't available and can't be installed, I used GNU `as` with
AT&T syntax and the `.code16gcc` pseudo-directive for real-mode 16-bit
code generation. This is a legitimate, precedented approach (used by
various GRUB-adjacent and older Linux boot code), but it's worth flagging
explicitly since most hobby-OS tutorials and expectations assume NASM.
If this becomes a blocker for the user's workflow, the boot code would
need a syntax rewrite — not done preemptively since it works as-is.

### Architecture decisions

**Two-stage boot.** A 512-byte MBR sector can't fit disk-read logic +
A20 enable + GDT setup + protected-mode switch + kernel loading. Stage 1
only loads Stage 2 (16 sectors / 8KB budget) via BIOS `INT 13h, AH=42h`
(LBA-addressed extended read — chosen over the older CHS-addressed
`AH=02h` because it's simpler to reason about and universally supported
in emulators and modern BIOS/UEFI-CSM).

**Boot-drive hand-off via fixed memory address, not linked symbols.**
Stage 1 and Stage 2 are assembled and `objcopy`'d to raw binaries
*separately* — they are never linked together into one ELF, since each
needs to be placed at a different fixed load address as raw machine code
for the BIOS to jump into directly. That means an `.extern` symbol
reference across the two files silently doesn't work (caught this while
writing stage2.S — first draft referenced `boot_drive` as an extern,
which would not have linked correctly). Fixed instead: both stages
hardcode address `0x0500` (a conventionally free low-memory scratch
location, just above the BIOS data area) as a hand-off slot for the
BIOS-provided boot drive number.

**Kernel loaded at 0x10000 (64KB mark), not 0x100000 (1MB mark).**
Real-mode BIOS disk reads can only target memory reachable in real mode
(effectively at/below ~1MB, and only cleanly below it without A20
trickery). Loading the kernel above 1MB would require either (a) a
real-mode-to-protected-mode copy step, or (b) "unreal mode" tricks to do
big real-mode memory moves. For a sub-512KB hobby kernel, staying below
1MB avoids all of that complexity for no real cost — there's ~576KB of
conventional memory between 0x10000 and the EBDA, comfortably more than
our entire size budget.

**A20 line: fast A20 method via port 0x92 only.** This is the simplest
of the ~3 common A20-enable methods and works on QEMU/Bochs and most real
hardware. The classic keyboard-controller method is more universally
compatible on *old* real hardware but adds real complexity for a case we
don't expect to hit. Flagged as a place to revisit if real-hardware
testing ever shows A20 isn't actually enabled.

**Flat GDT, ring 0 only, no paging yet.** Simplest possible protected-mode
memory model: two overlapping 4GB segments (code, data), no privilege
separation. Appropriate for where the project is right now; paging and
any privilege separation are explicitly deferred, not forgotten.

### Current size budget tracking

| Component  | Actual size | Budget    |
|------------|-------------|-----------|
| boot.bin   | 512 bytes   | 512 (fixed) |
| stage2.bin | 320 bytes   | 8192 (16 sectors) |
| kernel.bin | 320 bytes   | 51200 (100 sectors) |
| **Total image** | **59904 bytes (~58.5KB)** | **524288 (512KB)** |

Enormous headroom right now because the kernel only clears the screen and
prints two strings. This will fill up fast once memory management,
interrupts, the shell, filesystem, and apps land — tracked here at every
milestone from now on.

### What's verified vs. not

**Verified (statically):**
- boot.bin is exactly 512 bytes with correct `0x55AA` signature.
- Disassembly of boot.bin and stage2.bin matches the intended source
  logic instruction-by-instruction.
- kernel.elf places `_start` at 0x10000 and `kmain` immediately after,
  matching where stage2 jumps.
- Build produces a complete, correctly-laid-out disk image with no
  linker/assembler errors.

**Not yet verified (needs QEMU):**
- Does the BIOS actually load and jump to stage1 correctly?
- Does the extended INT13 disk read actually work in the emulator/on
  real BIOS?
- Does A20 actually get enabled?
- Does the protected-mode transition actually succeed (no triple fault)?
- Does the kernel actually run and produce visible VGA output?

**Next steps (pending your QEMU test results):**
1. Confirm Milestone 1 actually boots.
2. If it doesn't: debug using QEMU's `-d int,cpu_reset` logging and
   whatever output you can share.
3. If it does: move to Milestone 2 — interrupt handling (IDT, PIC
   remapping) and the system timer (PIT), since the shell and keyboard
   input both depend on interrupts working first.

---

## Bug #1: stage2 linked at wrong address (found via first real QEMU test)

**Symptom (reported by user, QEMU/SeaBIOS):** stage1's own messages
("loading stage2...", "stage2 loaded, jumping...") printed correctly, but
after the jump into stage2, the screen showed garbage characters (box-
drawing/symbol glyphs) instead of "ClaudeOS: stage2 running", then
stopped -- no hang message, no further progress.

**Root cause:** in the Makefile, stage2 was linked with
`ld -Ttext 0x0`, telling the linker to bake in absolute addresses as if
the code would be loaded starting at address 0. But stage1 actually
loads stage2 at linear address `0x7E00` (segment 0x0000, offset 0x7E00,
per the DAP in boot.S). So every absolute reference in stage2 -- e.g.
`mov $msg_stage2, %si` -- was compiled to point at address-relative-to-0
instead of address-relative-to-0x7E00. At runtime, `SI` ended up
pointing roughly 0x7E00 bytes before where the actual string data
lived, i.e. into unrelated low memory (IVT/BDA region), and
`print_string` dutifully printed whatever garbage bytes were sitting
there via `int 10h` -- which explains the box-drawing/symbol characters
exactly: not a crash, not a hang, just correct code faithfully printing
the wrong memory.

**Why this didn't get caught by static verification before shipping:**
I disassembled stage2.bin and manually read the instruction *shapes*
(mov, call, jc, etc.) and confirmed they matched the source's control
flow -- but I didn't cross-check the *absolute addresses* embedded in
those instructions against where the binary is actually loaded at
runtime. That's the gap: verifying "this looks like the right code" is
not the same as verifying "this code will do the right thing at its
actual load address." boot.bin happened to be linked correctly
(`-Ttext 0x7C00`, matching its real 0x7C00 load address), so it worked;
I didn't apply the same scrutiny to stage2's link address and used a
placeholder `0x0` without checking it against `STAGE2_LOAD_OFF`.

**Fix:** changed stage2's link address to `-Ttext 0x7E00`, matching
`STAGE2_LOAD_OFF` in both boot.S and stage2.S. Re-disassembled and
confirmed addresses embedded in the code now fall correctly within
stage2's actual 0x7E00+ load range (e.g. `mov $0x7e7f, %si` instead of
`mov $0x7f, %si`).

**Lesson applied going forward:** for every future raw-binary-linked
component, explicitly verify the link/load address match by
disassembling with `--adjust-vma` set to the real load address and
confirming embedded absolute addresses land inside that component's own
range -- not just that the instructions look structurally right.

**Status:** Fixed and confirmed working in QEMU (SeaBIOS) by the user —
full boot chain verified end to end: BIOS loads stage1, stage1 loads and
jumps to stage2, stage2 enables A20 and enters protected mode, kernel
runs and writes correctly to the VGA buffer. Milestone 1 complete.

---

## Milestone 2: Interrupts (IDT, exceptions, PIC remap, IRQs, PIT timer)

**Date:** 2026-08-22

### Scope

- IDT with all 256 vectors initialized (kernel/idt.c, kernel/idt_load.S).
- CPU exception handlers for vectors 0-31 (kernel/isr_stubs.S,
  kernel/isr.c) - currently a "panic" handler that prints the exception
  name, vector, error code, and faulting EIP/CS/EFLAGS to the screen
  and halts, rather than silently triple-faulting/rebooting. This is
  deliberately not fancy - there's no recovery mechanism yet since
  there's no process model to recover *to* - but it makes every future
  bug in this project vastly easier to diagnose than a blank reboot.
- 8259 PIC remap (kernel/pic.c) - hardware IRQs moved from their BIOS
  default vectors (which collide with CPU exceptions) to 32-47.
- Generic IRQ stub/dispatch layer (kernel/irq_stubs.S, kernel/irq.c)
  with a handler-registration table, so drivers (PIT now, keyboard
  next) don't need to touch the IDT or PIC directly.
- PIT (kernel/pit.c) programmed as a 100Hz system timer on IRQ0,
  counting ticks - the foundation for future delays/timeouts/scheduling.
- Extracted VGA text-mode output into a real driver (drivers/vga.c/h)
  instead of static functions living in kmain.c, since isr.c also needs
  it for panic output.

### Bug caught before shipping: object filename collision

`isr.S` and `isr.c` both would have compiled to `build/isr.o` (same for
`irq.S`/`irq.c`), silently overwriting one or the other depending on
build order. The linker then reported "multiple definition" errors for
every ISR/IRQ stub *and*, confusingly, "undefined reference" errors for
the C-side handler functions in the same build - because the surviving
isr.o was the C object, so the assembly stub symbols were missing
entirely from the link. Fixed by renaming the assembly files to
`isr_stubs.S` / `irq_stubs.S`. Caught immediately from the build output,
not from runtime behavior - a good reminder to actually read `make`'s
full output rather than just checking the exit code.

### Bug caught before shipping: .bss not zeroed

`objcopy -O binary` drops `.bss` from the output entirely - it's
reserved address space, not file content. That means nothing guarantees
zero-initialized statics (e.g. `irq_handlers[16]` in irq.c) actually
start at zero; they'd contain whatever was physically in that RAM
before our code ran. This happens to work by accident in QEMU (RAM
starts zeroed, and our sector padding also happens to zero-pad most of
the range in this case), but relying on that would be fragile and wrong
on real hardware or once more code loads before the kernel. Fixed by
adding `__bss_start`/`__bss_end` symbols to the linker script and an
explicit zeroing loop (`rep stosb`) at the very start of entry.S, before
the stack is even set up.

### Architecture decisions

**Panic instead of resume for exceptions.** Some hobby OSes try to
gracefully resume from certain exceptions. We don't, on purpose - with
no process/memory isolation model yet, "resuming" from e.g. a general
protection fault has no well-defined meaning. A clear diagnostic panic
screen is more honest and more useful right now than pretending to
recover.

**IRQs are edge cases of the same stub pattern as exceptions**, not a
totally separate mechanism - both push a vector number onto a uniform
stack frame and jump to a common C dispatcher. This is why irq.c's
`struct irq_frame` is structurally identical to isr.c's `struct
isr_frame`; kept as separate types rather than sharing one, since
exceptions and hardware interrupts are conceptually distinct even
though the plumbing happens to match.

**Driver registration table for IRQs, not hardcoded per-IRQ logic in
the dispatcher.** `irq_register_handler(0, pit_irq_handler)` keeps
pit.c from needing to know anything about IDT gates, PIC EOI, or stub
mechanics - it just says "call me on IRQ0." This is the pattern the
keyboard driver will follow next.

### Size budget tracking

| Component  | Actual size | Budget    |
|------------|-------------|-----------|
| boot.bin   | 512 bytes   | 512 (fixed) |
| stage2.bin | 320 bytes   | 8192 (16 sectors) |
| kernel.bin | 3425 bytes  | 51200 (100 sectors) |
| **Total image** | **59904 bytes (~58.5KB)** | **524288 (512KB)** |

Kernel grew from 320 -> 3425 bytes (interrupts/PIC/PIT/panic screen
infrastructure). Still enormous headroom.

### What's verified vs. not

**Verified (statically):** clean build with no unexpected warnings;
`_start`/`kmain`/`isr_common_handler`/`irq_common_handler` symbols land
at sensible, non-overlapping addresses; `__bss_start`/`__bss_end` bracket
a sane region including the kernel stack; disassembly of `idt_load` and
the ISR stub macro expansion matches intended logic.

**Not yet verified (needs QEMU):** does `lidt` actually succeed; do
exceptions actually route through our handlers (worth deliberately
triggering one, e.g. divide-by-zero, to see the panic screen); does the
PIC remap avoid breaking anything; does the PIT tick counter actually
increment on screen once per ~10ms.

**Status:** Confirmed working in QEMU by the user - IDT, PIC remap,
IRQ dispatch, and PIT timer all functioning correctly; tick counter
visibly incrementing on screen. Milestone 2 complete.

---

## Milestone 3: Keyboard input + basic shell

**Date:** 2026-08-23

### Scope

- PS/2 keyboard driver (drivers/keyboard.c/h) - reads scancode set 1
  from port 0x60 on IRQ1, translates to ASCII via a lookup table,
  handles Shift as a modifier, provides a blocking `keyboard_getchar()`
  and a `keyboard_read_line()` with backspace support. Extended
  (0xE0-prefixed) keys like arrow keys are consumed but not acted on
  yet - not needed until something wants line editing or navigation.
- Upgraded the VGA driver from fixed row/col printing to a real
  scrolling terminal (`term_clear`/`term_putc`/`term_print` in
  drivers/vga.c) with a tracked cursor, newline/backspace handling,
  scroll-up when text runs off the bottom, and hardware cursor sync via
  the VGA CRTC ports (0x3D4/0x3D5) so a blinking cursor is visible.
  vga_print_at (fixed-position) is kept as-is for boot-time status
  messages and the panic screen, which don't want scrolling behavior.
- Minimal string helpers (kernel/kstring.c/h: kstrlen, kstrcmp,
  kstrncmp) - freestanding builds have no libc, and the shell's command
  dispatch needs basic string comparison.
- Shell (kernel/shell.c/h): prompt/read/dispatch loop with built-in
  commands `help`, `clear`, `echo`, `uptime` (reads the PIT tick
  counter from Milestone 2), `version`, and `reboot`.

### Note on repo state at the start of this milestone

Keyboard.c/h, kstring.c/h, and shell.c/h were already present on disk
at the start of this work session, fully written, but kmain.c was
missing and the Makefile hadn't been updated to compile the new files.
Rather than assume this prior work was correct, I read every line of
each file against my own understanding of PS/2 scancode set 1, the
shell's expected behavior, and the existing codebase's conventions
before using any of it - confirming the scancode table entries against
the standard scancode-to-key mapping, checking the circular keyboard
buffer logic, and checking shell.c's command dispatch and reboot
sequence. All of it checked out and is used as-is. Wrote kmain.c to
wire it together and updated the Makefile to compile the missing
sources.

### Architecture decisions

**Blocking keyboard read via `hlt`, no polling.** `keyboard_getchar()`
spins in a `hlt` loop until the circular buffer has data. Since `hlt`
halts the CPU until the next interrupt (and the keyboard IRQ handler is
what fills the buffer), this is not a busy-wait burning CPU cycles -
the CPU is genuinely idle between keystrokes. This is the same pattern
the Milestone 2 kmain loop used while waiting for timer ticks.

**Two separate VGA output paths, not one.** `vga_print_at` (fixed
position, no cursor state) is kept for boot-time status lines and the
panic screen, which want to place text at known coordinates and are
one-shot. `term_*` (cursor-tracked, scrolling) is what the shell uses,
since a real console needs to remember where it left off and handle
overflow. Merging these into one API would have made the simpler
one-shot use case (panic screen) carry scrolling-cursor complexity it
doesn't need.

**Reboot via 8042 keyboard-controller reset pulse.** This is the
standard, widely-compatible software reboot trick for x86 (works on
real hardware going back decades and on QEMU/Bochs) - pulse the CPU
reset line through the keyboard controller's command port after
confirming its input buffer is clear. No ACPI/APM shutdown command
implemented yet - real ACPI shutdown requires parsing ACPI tables
(FADT/DSDT) to find the correct PM1 control port and values, which is
a meaningfully bigger feature deferred to a later milestone rather than
implemented as a fragile guess now.

### Size budget tracking

| Component  | Actual size | Budget    |
|------------|-------------|-----------|
| boot.bin   | 512 bytes   | 512 (fixed) |
| stage2.bin | 320 bytes   | 8192 (16 sectors) |
| kernel.bin | 6401 bytes  | 51200 (100 sectors) |
| **Total image** | **59904 bytes (~58.5KB)** | **524288 (512KB)** |

### What's verified vs. not

**Verified (statically):** clean build, zero unexpected warnings, zero
undefined symbols in the final ELF (`nm -u` empty); disassembly of
`shell_run` confirms it calls `term_print` then `keyboard_read_line`
with the arguments the source specifies; disassembly of the PIC/port-IO
code shows sane `in`/`out` instruction sequences: manual line-by-line
review of the keyboard scancode table against the standard PS/2 set-1
layout.

**Not yet verified (needs QEMU):** does the keyboard actually produce
correct characters on screen (including Shift); does Backspace behave
correctly at the start of a line (should not erase past where the
prompt starts, though the current implementation doesn't specifically
protect against backspacing into "> " - worth checking); do `help`,
`echo`, `uptime`, `version` behave as expected; does `reboot` actually
reboot the emulator or the "did not reset" fallback fire instead; does
the terminal scroll correctly once enough lines have been printed.

**Known gap to watch for:** `keyboard_read_line` has no protection
against Backspace deleting past the start of the current input line
into the "> " prompt itself, since it only tracks `len` (characters
typed this line) and stops at `len == 0` - so this should actually be
safe (backspace is a no-op once len reaches 0), but it's worth
confirming visually since terminal cursor/erase bugs are easy to miss
by inspection alone.

**Next steps:** confirm the shell is interactive and usable. Then
Milestone 4 (per the original roadmap): memory management, followed by
persistent storage - the shell's command surface won't get much more
interesting until there's a filesystem for it to act on.
