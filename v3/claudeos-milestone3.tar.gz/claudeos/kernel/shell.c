/*
 * ClaudeOS shell.
 *
 * A minimal command loop: print a prompt, read a line, dispatch to a
 * built-in command. No filesystem or app-launching yet, so commands
 * are hardcoded here - that will change once storage (Milestone
 * "Persistent Storage") and app-launching land, at which point this
 * dispatch table gets replaced with something that can also invoke
 * loaded programs.
 */

#include "shell.h"
#include "vga.h"
#include "keyboard.h"
#include "kstring.h"
#include "pit.h"
#include "ports.h"

#define CMD_BUFFER_SIZE 128

static void print_uint(unsigned int value) {
    char buf[16];
    int pos = 15;
    buf[pos] = '\0';
    if (value == 0) {
        buf[--pos] = '0';
    } else {
        while (value > 0 && pos > 0) {
            buf[--pos] = (char)('0' + (value % 10));
            value /= 10;
        }
    }
    term_print(&buf[pos]);
}

static void cmd_help(void) {
    term_print("Available commands:\n");
    term_print("  help     - show this list\n");
    term_print("  clear    - clear the screen\n");
    term_print("  echo X   - print X back\n");
    term_print("  uptime   - show system timer ticks since boot\n");
    term_print("  version  - show ClaudeOS version info\n");
    term_print("  reboot   - restart the machine\n");
}

static void cmd_echo(const char *args) {
    term_print(args);
    term_print("\n");
}

static void cmd_uptime(void) {
    term_print("Ticks since boot: ");
    print_uint(pit_get_ticks());
    term_print(" (100 ticks = 1 second)\n");
}

static void cmd_version(void) {
    term_print("ClaudeOS - Milestone 3 (keyboard input + shell)\n");
}

static void cmd_reboot(void) {
    term_print("Rebooting...\n");
    /* Classic PS/2 controller reboot trick: pulse the CPU reset line
       via the keyboard controller's command port. Wait for the input
       buffer to be clear first (bit 1 of the status port) so we don't
       send this while the controller is busy with something else. */
    unsigned char status;
    do {
        status = inb(0x64);
    } while (status & 0x02);
    outb(0x64, 0xFE);

    /* If the reset didn't take (some emulators/hardware are picky),
       don't silently hang - say so and halt cleanly. */
    term_print("Reboot signal sent but system did not reset.\n");
    for (;;) {
        __asm__ volatile ("cli; hlt");
    }
}

static void dispatch(char *line) {
    /* Trim nothing fancy - just find the first space to split
       command from arguments, if any. */
    int i = 0;
    while (line[i] != '\0' && line[i] != ' ') i++;

    char saved = line[i];
    line[i] = '\0';
    const char *cmd = line;
    const char *args = (saved == ' ') ? &line[i + 1] : "";

    if (kstrlen(cmd) == 0) {
        return; /* empty line - just show the prompt again */
    } else if (kstrcmp(cmd, "help") == 0) {
        cmd_help();
    } else if (kstrcmp(cmd, "clear") == 0) {
        term_clear();
    } else if (kstrcmp(cmd, "echo") == 0) {
        cmd_echo(args);
    } else if (kstrcmp(cmd, "uptime") == 0) {
        cmd_uptime();
    } else if (kstrcmp(cmd, "version") == 0) {
        cmd_version();
    } else if (kstrcmp(cmd, "reboot") == 0) {
        cmd_reboot();
    } else {
        term_print("Unknown command: ");
        term_print(cmd);
        term_print(" (type 'help' for a list)\n");
    }
}

void shell_run(void) {
    char line[CMD_BUFFER_SIZE];

    term_print("\nClaudeOS shell - type 'help' for available commands\n\n");

    for (;;) {
        term_print("> ");
        keyboard_read_line(line, CMD_BUFFER_SIZE);
        dispatch(line);
    }
}
