#ifndef CLAUDEOS_KSTRING_H
#define CLAUDEOS_KSTRING_H

int kstrlen(const char *s);
int kstrcmp(const char *a, const char *b);
int kstrncmp(const char *a, const char *b, int n);

#endif
