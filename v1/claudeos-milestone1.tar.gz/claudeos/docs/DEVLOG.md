# ClaudeOS Development Log

## Milestone 1: Boot chain (stage1 -> stage2 -> protected mode -> C kernel)

**Date:** 2026-08-22

### Environment constraints discovered

Before writing any code, I checked the actual dev sandbox tooling rather
than assuming a typical OS-dev setup:

- `nasm`: not installed, and the sandbox has no internet access, so
  `apt-get install nasm` fails (confirmed — 403s from the package mirror).
- `qemu-system-x86_64` / `qemu-system-i386`: not installed, same problem.
  No QEMU binary exists anywhere on the filesystem.
- `gcc`, `binutils` (`as`, `ld`, `objcopy`), `make`: all present.

**Consequence:** I cannot boot-test this project myself in this
environment. This is an important limitation to be upfront about per the
project's own ground rules ("do not pretend code works if it has not been
tested"). What I *can* do, and have done, is static verification:
- Confirm the boot sector is exactly 512 bytes ending in `0x55 0xAA`.
- Disassemble the built binaries and manually check the decoded
  instructions match the intended source logic.
- Confirm linker-placed symbol addresses match the addresses the
  bootloader jumps to.

This does not replace actually booting it. **The first real test needs to
happen in QEMU on the user's machine.** See README.md for exact commands.

### Assembler substitution: GAS instead of NASM

Since NASM isn't available and can't be installed, I used GNU `as` with
AT&T syntax and the `.code16gcc` pseudo-directive for real-mode 16-bit
code generation. This is a legitimate, precedented approach (used by
various GRUB-adjacent and older Linux boot code), but it's worth flagging
explicitly since most hobby-OS tutorials and expectations assume NASM.
If this becomes a blocker for the user's workflow, the boot code would
need a syntax rewrite — not done preemptively since it works as-is.

### Architecture decisions

**Two-stage boot.** A 512-byte MBR sector can't fit disk-read logic +
A20 enable + GDT setup + protected-mode switch + kernel loading. Stage 1
only loads Stage 2 (16 sectors / 8KB budget) via BIOS `INT 13h, AH=42h`
(LBA-addressed extended read — chosen over the older CHS-addressed
`AH=02h` because it's simpler to reason about and universally supported
in emulators and modern BIOS/UEFI-CSM).

**Boot-drive hand-off via fixed memory address, not linked symbols.**
Stage 1 and Stage 2 are assembled and `objcopy`'d to raw binaries
*separately* — they are never linked together into one ELF, since each
needs to be placed at a different fixed load address as raw machine code
for the BIOS to jump into directly. That means an `.extern` symbol
reference across the two files silently doesn't work (caught this while
writing stage2.S — first draft referenced `boot_drive` as an extern,
which would not have linked correctly). Fixed instead: both stages
hardcode address `0x0500` (a conventionally free low-memory scratch
location, just above the BIOS data area) as a hand-off slot for the
BIOS-provided boot drive number.

**Kernel loaded at 0x10000 (64KB mark), not 0x100000 (1MB mark).**
Real-mode BIOS disk reads can only target memory reachable in real mode
(effectively at/below ~1MB, and only cleanly below it without A20
trickery). Loading the kernel above 1MB would require either (a) a
real-mode-to-protected-mode copy step, or (b) "unreal mode" tricks to do
big real-mode memory moves. For a sub-512KB hobby kernel, staying below
1MB avoids all of that complexity for no real cost — there's ~576KB of
conventional memory between 0x10000 and the EBDA, comfortably more than
our entire size budget.

**A20 line: fast A20 method via port 0x92 only.** This is the simplest
of the ~3 common A20-enable methods and works on QEMU/Bochs and most real
hardware. The classic keyboard-controller method is more universally
compatible on *old* real hardware but adds real complexity for a case we
don't expect to hit. Flagged as a place to revisit if real-hardware
testing ever shows A20 isn't actually enabled.

**Flat GDT, ring 0 only, no paging yet.** Simplest possible protected-mode
memory model: two overlapping 4GB segments (code, data), no privilege
separation. Appropriate for where the project is right now; paging and
any privilege separation are explicitly deferred, not forgotten.

### Current size budget tracking

| Component  | Actual size | Budget    |
|------------|-------------|-----------|
| boot.bin   | 512 bytes   | 512 (fixed) |
| stage2.bin | 320 bytes   | 8192 (16 sectors) |
| kernel.bin | 320 bytes   | 51200 (100 sectors) |
| **Total image** | **59904 bytes (~58.5KB)** | **524288 (512KB)** |

Enormous headroom right now because the kernel only clears the screen and
prints two strings. This will fill up fast once memory management,
interrupts, the shell, filesystem, and apps land — tracked here at every
milestone from now on.

### What's verified vs. not

**Verified (statically):**
- boot.bin is exactly 512 bytes with correct `0x55AA` signature.
- Disassembly of boot.bin and stage2.bin matches the intended source
  logic instruction-by-instruction.
- kernel.elf places `_start` at 0x10000 and `kmain` immediately after,
  matching where stage2 jumps.
- Build produces a complete, correctly-laid-out disk image with no
  linker/assembler errors.

**Not yet verified (needs QEMU):**
- Does the BIOS actually load and jump to stage1 correctly?
- Does the extended INT13 disk read actually work in the emulator/on
  real BIOS?
- Does A20 actually get enabled?
- Does the protected-mode transition actually succeed (no triple fault)?
- Does the kernel actually run and produce visible VGA output?

**Next steps (pending your QEMU test results):**
1. Confirm Milestone 1 actually boots.
2. If it doesn't: debug using QEMU's `-d int,cpu_reset` logging and
   whatever output you can share.
3. If it does: move to Milestone 2 — interrupt handling (IDT, PIC
   remapping) and the system timer (PIT), since the shell and keyboard
   input both depend on interrupts working first.
