# ClaudeOS

A tiny x86 operating system built from scratch as an AI-development experiment.
No existing kernel is used as a foundation — bootloader, protected-mode switch,
and kernel are all original code written for this project.

## Status: Milestone 1 — boot chain works (untested in emulator by the author)

See `docs/DEVLOG.md` for full development history, design rationale, and
known limitations.

**Important note on testing:** this project was developed in a sandboxed
environment with no internet access, so the AI author could not install or
run QEMU to test the boot chain itself. Everything has been verified
statically (boot signature, disassembly matching source logic, correct
linker symbol placement) but **has not yet been confirmed to actually boot**.
If you're picking this up, running it in QEMU (see below) is the first
thing to do, and the results should be fed back in to continue development.

## Toolchain

- GNU `as` (binutils) — **not NASM**. Real-mode code uses GAS's `.code16gcc`
  directive. This was a substitution forced by tool availability in the dev
  sandbox (no NASM installed, no internet to install it), not a design choice.
  If you prefer NASM, the assembly would need syntax conversion (Intel vs
  AT&T, directive differences) — not currently planned unless it becomes a
  problem.
- `gcc -m32 -ffreestanding -nostdlib` for kernel C code.
- GNU `ld` with a linker script for the kernel, and raw `--oformat binary`
  linking for the boot stages.
- `make` for the build.

## Building

```sh
make            # builds build/claudeos.img
make size       # shows component and total image sizes vs the 512KB budget
make clean
```

Requires: `gcc`, `binutils` (`as`, `ld`, `objcopy`), `make`. All standard on
any Linux dev box; on Windows, use WSL2 with these installed (or a Linux
container) — see docs/DEVLOG.md for why native Windows isn't the build target.

## Testing in QEMU

You'll need QEMU installed (`qemu-system-x86_64` or `qemu-system-i386`).
On Windows: install via https://www.qemu.org/download/#windows, or use WSL2
with `sudo apt install qemu-system-x86`.

```sh
qemu-system-x86_64 -drive format=raw,file=build/claudeos.img
```

**Expected result** if everything works: a text-mode screen showing:
```
ClaudeOS: loading stage2...
ClaudeOS: stage2 running
ClaudeOS: enabling A20
ClaudeOS: entering protected mode
ClaudeOS - Milestone 1: boot chain OK
Stage1 -> Stage2 -> Protected Mode -> C kernel
If you can read this in QEMU, the bootloader works.
```
The BIOS messages print via `int 0x10` teletype, then the kernel clears the
screen and writes its own two lines via direct VGA buffer access — so seeing
*both* the early boot messages scroll by *and* the final clean-screen kernel
output confirms every stage ran.

**If it hangs, triple-faults/reboots, or shows garbage:** please paste back
the QEMU output (add `-d int,cpu_reset -no-reboot -no-shutdown` to the QEMU
command line to get useful crash diagnostics logged) and I'll debug from
there.

## Testing on real hardware

Not recommended yet at this milestone — write `claudeos.img` to a USB drive
with `dd` only once QEMU boot is confirmed working. (`dd if=build/claudeos.img
of=/dev/sdX bs=512` — **be extremely careful with the target device path**.)

## Project layout

```
boot/       Stage 1 (MBR) and Stage 2 bootloaders (GAS assembly)
kernel/     Kernel entry point (asm) + kmain and future kernel C code
drivers/    (future) hardware drivers
fs/         (future) filesystem
apps/       (future) built-in applications
games/      (future) built-in games
build/      Build output (gitignored)
docs/       Development log and design notes
```

## Disk image layout (current)

| Sectors | Contents        | Size budget |
|---------|-----------------|-------------|
| 0       | Stage 1 (MBR)   | 512 bytes (fixed) |
| 1–16    | Stage 2         | 8 KB |
| 17–116  | Kernel          | 50 KB |

These budgets are placeholders picked to leave headroom; see the 512KB
tracking in `docs/DEVLOG.md`.
