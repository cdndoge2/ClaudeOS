/*
 * ClaudeOS kernel - kmain
 *
 * Milestone 1 scope: prove the full boot chain works end to end.
 * That means: stage1 -> stage2 -> protected mode -> C code running ->
 * writing directly to the VGA text-mode buffer.
 *
 * Nothing here is architected for reuse yet beyond the VGA helpers,
 * which we'll keep as the seed of a real driver in a later stage.
 */

#define VGA_MEMORY   ((volatile unsigned short *)0xB8000)
#define VGA_WIDTH    80
#define VGA_HEIGHT   25
#define VGA_COLOR    0x0F /* white on black */

static void vga_clear(void) {
    for (int i = 0; i < VGA_WIDTH * VGA_HEIGHT; i++) {
        VGA_MEMORY[i] = (VGA_COLOR << 8) | ' ';
    }
}

static void vga_print_at(const char *str, int row, int col) {
    int offset = row * VGA_WIDTH + col;
    for (int i = 0; str[i] != '\0'; i++) {
        VGA_MEMORY[offset + i] = (VGA_COLOR << 8) | (unsigned char)str[i];
    }
}

void kmain(void) {
    vga_clear();
    vga_print_at("ClaudeOS - Milestone 1: boot chain OK", 0, 0);
    vga_print_at("Stage1 -> Stage2 -> Protected Mode -> C kernel", 1, 0);
    vga_print_at("If you can read this in QEMU, the bootloader works.", 3, 0);

    for (;;) {
        __asm__ volatile ("hlt");
    }
}
