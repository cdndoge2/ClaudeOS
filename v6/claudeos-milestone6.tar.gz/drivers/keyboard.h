#ifndef CLAUDEOS_KEYBOARD_H
#define CLAUDEOS_KEYBOARD_H

void keyboard_init(void);

/* Returns the next available character (blocking - halts the CPU in a
   loop until a key is pressed, which is fine since we have no other
   work to do while idle and `hlt` wakes on the next interrupt). */
char keyboard_getchar(void);

/* Reads a full line into buf (up to max_len-1 chars), echoing each
   character to the terminal and handling backspace. Null-terminates
   buf. Stops on Enter (the newline itself is echoed but not stored). */
void keyboard_read_line(char *buf, int max_len);

#endif
