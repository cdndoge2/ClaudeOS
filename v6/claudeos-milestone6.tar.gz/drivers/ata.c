/*
 * ATA PIO mode disk driver.
 *
 * Talks to the primary IDE channel's master drive using LBA28
 * addressing and polled (not interrupt-driven) PIO transfers. This is
 * the classic "works everywhere" approach for a hobby OS - no DMA, no
 * IRQ14 handler, just busy-waiting on the status register between
 * 256-word sector transfers. QEMU's default disk image is attached
 * here (primary master), which is why this is the right starting
 * point rather than, say, AHCI/SATA - PIO/IDE is what every x86
 * emulator and essentially all real hardware still supports even
 * decades after being "obsolete," precisely because it's simple
 * enough that BIOSes and OSes never stopped relying on it as a
 * fallback.
 *
 * Only single-sector-at-a-time semantics are exposed at the driver
 * level even though the loop supports multi-sector transfers, since
 * that keeps the per-sector status-polling logic in one place rather
 * than duplicated for a "transfer many at once" fast path we don't
 * need yet.
 */

#include "ata.h"
#include "ports.h"

#define ATA_PRIMARY_DATA        0x1F0
#define ATA_PRIMARY_ERROR       0x1F1
#define ATA_PRIMARY_SECCOUNT    0x1F2
#define ATA_PRIMARY_LBA_LOW     0x1F3
#define ATA_PRIMARY_LBA_MID     0x1F4
#define ATA_PRIMARY_LBA_HIGH    0x1F5
#define ATA_PRIMARY_DRIVE_HEAD  0x1F6
#define ATA_PRIMARY_COMMAND     0x1F7
#define ATA_PRIMARY_STATUS      0x1F7

#define ATA_CMD_READ_SECTORS    0x20
#define ATA_CMD_WRITE_SECTORS   0x30
#define ATA_CMD_CACHE_FLUSH     0xE7

#define ATA_STATUS_ERR  0x01
#define ATA_STATUS_DRQ  0x08
#define ATA_STATUS_DF   0x20
#define ATA_STATUS_BSY  0x80

#define ATA_TIMEOUT_ITERATIONS 100000

/*
 * Waits for BSY to clear. Returns 0 on success, -1 on timeout.
 * A bounded timeout (rather than looping forever) means a
 * disconnected/misbehaving drive gives a diagnosable failure instead
 * of hanging the whole kernel - worth the small extra complexity.
 */
static int wait_not_busy(void) {
    for (int i = 0; i < ATA_TIMEOUT_ITERATIONS; i++) {
        unsigned char status = inb(ATA_PRIMARY_STATUS);
        if (!(status & ATA_STATUS_BSY)) {
            return 0;
        }
    }
    return -1;
}

/* Waits for DRQ (data ready) to be set, or bails out on ERR/DF/timeout. */
static int wait_drq(void) {
    for (int i = 0; i < ATA_TIMEOUT_ITERATIONS; i++) {
        unsigned char status = inb(ATA_PRIMARY_STATUS);
        if (status & (ATA_STATUS_ERR | ATA_STATUS_DF)) {
            return -1;
        }
        if (status & ATA_STATUS_DRQ) {
            return 0;
        }
    }
    return -1;
}

static void select_drive_lba(unsigned int lba) {
    /* 0xE0 = LBA mode, master drive (bit4=0), reserved bits set per
       spec; top 4 bits of a 28-bit LBA go in the low nibble. */
    outb(ATA_PRIMARY_DRIVE_HEAD, (unsigned char)(0xE0 | ((lba >> 24) & 0x0F)));
    /* Drive/head select needs ~400ns to settle before the status
       register is meaningful - four reads of an unused port is the
       conventional way to burn that time (see ports.h's io_wait). */
    io_wait(); io_wait(); io_wait(); io_wait();
}

static void set_lba_and_count(unsigned int lba, unsigned char count) {
    outb(ATA_PRIMARY_SECCOUNT, count);
    outb(ATA_PRIMARY_LBA_LOW,  (unsigned char)(lba & 0xFF));
    outb(ATA_PRIMARY_LBA_MID,  (unsigned char)((lba >> 8) & 0xFF));
    outb(ATA_PRIMARY_LBA_HIGH, (unsigned char)((lba >> 16) & 0xFF));
}

int ata_read_sectors(unsigned int lba, unsigned char count, void *buffer) {
    if (count == 0) {
        return -1; /* 0 means "256" per the ATA spec - not supported
                       here to avoid that ambiguity; callers needing
                       256 sectors in one call should split it, though
                       nothing in this project currently needs to. */
    }

    select_drive_lba(lba);
    if (wait_not_busy() != 0) {
        return -1;
    }

    set_lba_and_count(lba, count);
    outb(ATA_PRIMARY_COMMAND, ATA_CMD_READ_SECTORS);

    unsigned short *dest = (unsigned short *)buffer;
    for (unsigned char sector = 0; sector < count; sector++) {
        if (wait_drq() != 0) {
            return -1;
        }
        for (int word = 0; word < 256; word++) {
            *dest++ = inw(ATA_PRIMARY_DATA);
        }
    }

    return 0;
}

int ata_write_sectors(unsigned int lba, unsigned char count, const void *buffer) {
    if (count == 0) {
        return -1;
    }

    select_drive_lba(lba);
    if (wait_not_busy() != 0) {
        return -1;
    }

    set_lba_and_count(lba, count);
    outb(ATA_PRIMARY_COMMAND, ATA_CMD_WRITE_SECTORS);

    const unsigned short *src = (const unsigned short *)buffer;
    for (unsigned char sector = 0; sector < count; sector++) {
        if (wait_drq() != 0) {
            return -1;
        }
        for (int word = 0; word < 256; word++) {
            outw(ATA_PRIMARY_DATA, *src++);
        }
    }

    /* Flush the drive's write cache so the data is actually committed
       rather than sitting in a volatile cache - matters for real
       hardware; harmless no-op-ish on QEMU's raw-file-backed disks
       but correct practice either way. */
    if (wait_not_busy() != 0) {
        return -1;
    }
    outb(ATA_PRIMARY_COMMAND, ATA_CMD_CACHE_FLUSH);
    if (wait_not_busy() != 0) {
        return -1;
    }

    return 0;
}
