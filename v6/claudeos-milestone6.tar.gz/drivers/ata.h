#ifndef CLAUDEOS_ATA_H
#define CLAUDEOS_ATA_H

/* Returns 0 on success, non-zero on error (timeout or device error). */
int ata_read_sectors(unsigned int lba, unsigned char count, void *buffer);
int ata_write_sectors(unsigned int lba, unsigned char count, const void *buffer);

#endif
