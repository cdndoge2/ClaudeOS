#include "vga.h"
#include "ports.h"

#define VGA_MEMORY   ((volatile unsigned short *)0xB8000)
#define VGA_WIDTH    80
#define VGA_HEIGHT   25

#define COLOR_NORMAL 0x0F  /* white on black */
#define COLOR_PANIC  0x4F  /* white on red */

static unsigned char current_color = COLOR_NORMAL;

void vga_clear(void) {
    for (int i = 0; i < VGA_WIDTH * VGA_HEIGHT; i++) {
        VGA_MEMORY[i] = (current_color << 8) | ' ';
    }
}

void vga_print_at(const char *str, int row, int col) {
    int offset = row * VGA_WIDTH + col;
    for (int i = 0; str[i] != '\0'; i++) {
        VGA_MEMORY[offset + i] = (current_color << 8) | (unsigned char)str[i];
    }
}

void vga_panic_screen(void) {
    current_color = COLOR_PANIC;
    vga_clear();
}

/* Minimal hex formatter - no snprintf available (freestanding, no libc). */
static void format_hex32(unsigned int value, char *out) {
    const char *digits = "0123456789ABCDEF";
    out[0] = '0';
    out[1] = 'x';
    for (int i = 0; i < 8; i++) {
        unsigned int shift = (7 - i) * 4;
        out[2 + i] = digits[(value >> shift) & 0xF];
    }
    out[10] = '\0';
}

void vga_print_kv(const char *label, unsigned int value, int row, int col) {
    vga_print_at(label, row, col);

    int label_len = 0;
    while (label[label_len] != '\0') label_len++;

    vga_print_at(": ", row, col + label_len);

    char hexbuf[11];
    format_hex32(value, hexbuf);
    vga_print_at(hexbuf, row, col + label_len + 2);
}

/* ---------------- Scrolling terminal ---------------- */

#define VGA_PORT_INDEX 0x3D4
#define VGA_PORT_DATA  0x3D5

static int term_row = 0;
static int term_col = 0;

static void term_update_hw_cursor(void) {
    unsigned short pos = (unsigned short)(term_row * VGA_WIDTH + term_col);
    outb(VGA_PORT_INDEX, 0x0F);
    outb(VGA_PORT_DATA, (unsigned char)(pos & 0xFF));
    outb(VGA_PORT_INDEX, 0x0E);
    outb(VGA_PORT_DATA, (unsigned char)((pos >> 8) & 0xFF));
}

static void term_scroll_if_needed(void) {
    if (term_row < VGA_HEIGHT) {
        return;
    }
    /* Move every row up by one */
    for (int row = 1; row < VGA_HEIGHT; row++) {
        for (int col = 0; col < VGA_WIDTH; col++) {
            VGA_MEMORY[(row - 1) * VGA_WIDTH + col] = VGA_MEMORY[row * VGA_WIDTH + col];
        }
    }
    /* Clear the freed last row */
    for (int col = 0; col < VGA_WIDTH; col++) {
        VGA_MEMORY[(VGA_HEIGHT - 1) * VGA_WIDTH + col] = (current_color << 8) | ' ';
    }
    term_row = VGA_HEIGHT - 1;
}

void term_clear(void) {
    current_color = COLOR_NORMAL;
    vga_clear();
    term_row = 0;
    term_col = 0;
    term_update_hw_cursor();
}

void term_putc(char c) {
    if (c == '\n') {
        term_row++;
        term_col = 0;
    } else if (c == '\b') {
        if (term_col > 0) {
            term_col--;
            VGA_MEMORY[term_row * VGA_WIDTH + term_col] = (current_color << 8) | ' ';
        } else if (term_row > 0) {
            term_row--;
            term_col = VGA_WIDTH - 1;
            VGA_MEMORY[term_row * VGA_WIDTH + term_col] = (current_color << 8) | ' ';
        }
        /* At (0,0) there's nothing to erase - do nothing rather than
           blanking the character already sitting at the origin. */
    } else {
        VGA_MEMORY[term_row * VGA_WIDTH + term_col] = (current_color << 8) | (unsigned char)c;
        term_col++;
        if (term_col >= VGA_WIDTH) {
            term_col = 0;
            term_row++;
        }
    }

    term_scroll_if_needed();
    term_update_hw_cursor();
}

void term_print(const char *str) {
    for (int i = 0; str[i] != '\0'; i++) {
        term_putc(str[i]);
    }
}
