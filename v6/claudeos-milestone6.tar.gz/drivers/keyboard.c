/*
 * PS/2 keyboard driver.
 *
 * Reads raw scancodes (set 1, the PC/XT default and what QEMU's
 * emulated PS/2 controller uses) from port 0x60 on every IRQ1, and
 * translates them to ASCII via a fixed lookup table. Only basic keys
 * are handled: printable characters, Enter, Backspace, and Shift as a
 * modifier. Extended (0xE0-prefixed) keys - arrow keys, etc. - are
 * currently just consumed and ignored rather than acted on; the shell
 * doesn't need them yet.
 */

#include "keyboard.h"
#include "vga.h"
#include "ports.h"
#include "irq.h"

#define KBD_DATA_PORT 0x60

/* Bit 7 set on a scancode means "key released" rather than "pressed";
   the low 7 bits are the same scancode either way. */
#define KEY_RELEASED_MASK 0x80

#define SCANCODE_LEFT_SHIFT_PRESS    0x2A
#define SCANCODE_RIGHT_SHIFT_PRESS   0x36
#define SCANCODE_LEFT_SHIFT_RELEASE  0xAA
#define SCANCODE_RIGHT_SHIFT_RELEASE 0xB6
#define SCANCODE_EXTENDED_PREFIX     0xE0

/* Scancode set 1 -> ASCII, unshifted. Index is the scancode (0-127).
   0 means "no ASCII equivalent" (modifier keys, function keys, etc). */
static const char scancode_to_ascii[128] = {
    0,   27,  '1', '2', '3', '4', '5', '6', '7', '8', /* 0-9 */
    '9', '0', '-', '=', '\b','\t','q', 'w', 'e', 'r', /* 10-19 */
    't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n', 0,   /* 20-29 (29=ctrl) */
    'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', /* 30-39 */
    '\'','`', 0,  '\\','z', 'x', 'c', 'v', 'b', 'n', /* 40-49 (42=lshift) */
    'm', ',', '.', '/', 0,   '*', 0,   ' ', 0,   0,   /* 50-59 (54=rshift,56=alt,57=space) */
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   /* 60-69 (F-keys, numlock, etc) */
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   /* 70-79 */
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   /* 80-89 */
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   /* 90-99 */
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   /* 100-109 */
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   /* 110-119 */
    0,   0,   0,   0,   0,   0,   0,   0                /* 120-127 */
};

/* Shifted variants for the keys people actually expect Shift to change.
   Anything not listed here falls back to the unshifted table (i.e.
   Shift has no effect on that key in our current implementation - no
   Caps Lock support either). */
static char apply_shift(char c) {
    if (c >= 'a' && c <= 'z') {
        return (char)(c - 'a' + 'A');
    }
    switch (c) {
        case '1': return '!';
        case '2': return '@';
        case '3': return '#';
        case '4': return '$';
        case '5': return '%';
        case '6': return '^';
        case '7': return '&';
        case '8': return '*';
        case '9': return '(';
        case '0': return ')';
        case '-': return '_';
        case '=': return '+';
        case '[': return '{';
        case ']': return '}';
        case ';': return ':';
        case '\'': return '"';
        case ',': return '<';
        case '.': return '>';
        case '/': return '?';
        case '`': return '~';
        case '\\': return '|';
        default: return c;
    }
}

/* Small circular buffer of translated characters, filled by the IRQ1
   handler and drained by keyboard_getchar(). Kept deliberately simple
   (no locking) since we're single-threaded with no preemption yet. */
#define KBD_BUFFER_SIZE 64
static volatile char kbd_buffer[KBD_BUFFER_SIZE];
static volatile int kbd_buf_head = 0; /* next write position */
static volatile int kbd_buf_tail = 0; /* next read position */

static int shift_held = 0;
static int extended_prefix_pending = 0;

static void kbd_buffer_push(char c) {
    int next_head = (kbd_buf_head + 1) % KBD_BUFFER_SIZE;
    if (next_head == kbd_buf_tail) {
        return; /* buffer full - drop the character rather than overwrite */
    }
    kbd_buffer[kbd_buf_head] = c;
    kbd_buf_head = next_head;
}

static void keyboard_irq_handler(void) {
    unsigned char scancode = inb(KBD_DATA_PORT);

    if (scancode == SCANCODE_EXTENDED_PREFIX) {
        extended_prefix_pending = 1;
        return;
    }
    if (extended_prefix_pending) {
        /* Consume and discard the byte following an extended prefix -
           we don't act on extended keys (arrows, etc.) yet. */
        extended_prefix_pending = 0;
        return;
    }

    if (scancode == SCANCODE_LEFT_SHIFT_PRESS || scancode == SCANCODE_RIGHT_SHIFT_PRESS) {
        shift_held = 1;
        return;
    }
    if (scancode == SCANCODE_LEFT_SHIFT_RELEASE || scancode == SCANCODE_RIGHT_SHIFT_RELEASE) {
        shift_held = 0;
        return;
    }

    if (scancode & KEY_RELEASED_MASK) {
        return; /* we only care about key-down for everything else */
    }

    char c = scancode_to_ascii[scancode & 0x7F];
    if (c == 0) {
        return; /* no ASCII mapping (function key, etc.) */
    }

    if (shift_held) {
        c = apply_shift(c);
    }

    kbd_buffer_push(c);
}

void keyboard_init(void) {
    irq_register_handler(1, keyboard_irq_handler);
}

char keyboard_getchar(void) {
    while (kbd_buf_head == kbd_buf_tail) {
        __asm__ volatile ("hlt");
    }
    char c = kbd_buffer[kbd_buf_tail];
    kbd_buf_tail = (kbd_buf_tail + 1) % KBD_BUFFER_SIZE;
    return c;
}

void keyboard_read_line(char *buf, int max_len) {
    int len = 0;
    for (;;) {
        char c = keyboard_getchar();

        if (c == '\n') {
            term_putc('\n');
            break;
        } else if (c == '\b') {
            if (len > 0) {
                len--;
                term_putc('\b');
            }
        } else if (len < max_len - 1) {
            buf[len++] = c;
            term_putc(c);
        }
        /* if the buffer is full, silently ignore further characters
           until Enter or Backspace - matches typical shell behavior */
    }
    buf[len] = '\0';
}
