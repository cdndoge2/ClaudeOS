#ifndef CLAUDEOS_VGA_H
#define CLAUDEOS_VGA_H

void vga_clear(void);
void vga_print_at(const char *str, int row, int col);

/* Clears the screen with an alarming color scheme (white on red) for
   exception/panic output, distinct from normal kernel output. */
void vga_panic_screen(void);

/* Prints "label: 0xXXXXXXXX" at the given row/col - used by the
   exception handler to dump register/vector values. */
void vga_print_kv(const char *label, unsigned int value, int row, int col);

/* ---- Scrolling terminal interface (used by the shell) ----
 * Tracks its own cursor position, handles newline/backspace, wraps at
 * the screen width, and scrolls the whole screen up when the cursor
 * runs off the bottom. This is a separate concern from vga_print_at
 * above (which is fixed-position, used for one-shot status screens
 * like boot messages and the panic screen) - the shell needs an
 * actual moving-cursor terminal instead. */
void term_clear(void);
void term_putc(char c);
void term_print(const char *str);

#endif

