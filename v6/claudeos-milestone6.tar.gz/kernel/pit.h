#ifndef CLAUDEOS_PIT_H
#define CLAUDEOS_PIT_H

void pit_init(unsigned int frequency_hz);
unsigned int pit_get_ticks(void);

#endif
