/*
 * PIT (Programmable Interval Timer) driver.
 *
 * The PIT's channel 0 is wired to IRQ0 and is the traditional PC
 * system timer. We program it to fire at a chosen frequency and count
 * ticks in an IRQ handler - this tick count is what future scheduling,
 * sleep/delay functions, and timeouts will be built on.
 */

#include "pit.h"
#include "ports.h"
#include "irq.h"

#define PIT_CHANNEL0_DATA 0x40
#define PIT_COMMAND       0x43
#define PIT_BASE_FREQUENCY 1193182 /* Hz - fixed PIT input clock frequency */

static volatile unsigned int tick_count = 0;

static void pit_irq_handler(void) {
    tick_count++;
}

void pit_init(unsigned int frequency_hz) {
    if (frequency_hz == 0) {
        frequency_hz = 100;
    }

    unsigned int divisor = PIT_BASE_FREQUENCY / frequency_hz;

    /* Command byte: channel 0, access mode lobyte/hibyte, mode 3
       (square wave generator), binary mode */
    outb(PIT_COMMAND, 0x36);

    outb(PIT_CHANNEL0_DATA, (unsigned char)(divisor & 0xFF));
    outb(PIT_CHANNEL0_DATA, (unsigned char)((divisor >> 8) & 0xFF));

    irq_register_handler(0, pit_irq_handler);
}

unsigned int pit_get_ticks(void) {
    return tick_count;
}
