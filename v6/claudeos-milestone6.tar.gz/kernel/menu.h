#ifndef CLAUDEOS_MENU_H
#define CLAUDEOS_MENU_H

/* Runs forever - the top-level UI loop kmain hands control to after
   boot. Individual apps/games are launched and return here when they
   exit; there's no way to "leave" the menu except reboot. */
void menu_run(void);

#endif
