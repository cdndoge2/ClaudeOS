#include "idt.h"
#include "pic.h"

#define DECLARE_IRQ(n) extern void irq##n(void);
DECLARE_IRQ(0)  DECLARE_IRQ(1)  DECLARE_IRQ(2)  DECLARE_IRQ(3)
DECLARE_IRQ(4)  DECLARE_IRQ(5)  DECLARE_IRQ(6)  DECLARE_IRQ(7)
DECLARE_IRQ(8)  DECLARE_IRQ(9)  DECLARE_IRQ(10) DECLARE_IRQ(11)
DECLARE_IRQ(12) DECLARE_IRQ(13) DECLARE_IRQ(14) DECLARE_IRQ(15)

/* Same layout as isr.c's isr_frame - see that file for how each field
   maps to the assembly push sequence. vector here will be 32-47. */
struct irq_frame {
    unsigned int ds;
    unsigned int edi, esi, ebp, esp_dummy, ebx, edx, ecx, eax;
    unsigned int vector, error_code;
    unsigned int eip, cs, eflags;
};

/* Per-IRQ handler table. Drivers (keyboard, PIT, etc.) register into
   this instead of touching the IDT directly - keeps driver code from
   needing to know about stub mechanics or PIC EOI at all. */
#define NUM_IRQS 16
typedef void (*irq_handler_t)(void);
static irq_handler_t irq_handlers[NUM_IRQS] = {0};

void irq_register_handler(int irq, irq_handler_t handler) {
    if (irq >= 0 && irq < NUM_IRQS) {
        irq_handlers[irq] = handler;
    }
}

void irq_common_handler(struct irq_frame *frame) {
    int irq = (int)(frame->vector - 32);

    if (irq >= 0 && irq < NUM_IRQS && irq_handlers[irq] != 0) {
        irq_handlers[irq]();
    }

    /* Always send EOI, even if no handler is registered, so the PIC
       doesn't get stuck thinking an IRQ is still "in service" and
       stop delivering further interrupts on that line. */
    pic_send_eoi((unsigned char)irq);
}

void irq_install_all(void) {
    idt_set_handler(32, (unsigned int)irq0);
    idt_set_handler(33, (unsigned int)irq1);
    idt_set_handler(34, (unsigned int)irq2);
    idt_set_handler(35, (unsigned int)irq3);
    idt_set_handler(36, (unsigned int)irq4);
    idt_set_handler(37, (unsigned int)irq5);
    idt_set_handler(38, (unsigned int)irq6);
    idt_set_handler(39, (unsigned int)irq7);
    idt_set_handler(40, (unsigned int)irq8);
    idt_set_handler(41, (unsigned int)irq9);
    idt_set_handler(42, (unsigned int)irq10);
    idt_set_handler(43, (unsigned int)irq11);
    idt_set_handler(44, (unsigned int)irq12);
    idt_set_handler(45, (unsigned int)irq13);
    idt_set_handler(46, (unsigned int)irq14);
    idt_set_handler(47, (unsigned int)irq15);
}
