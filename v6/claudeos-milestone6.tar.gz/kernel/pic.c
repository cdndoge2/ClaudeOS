/*
 * 8259 PIC (Programmable Interrupt Controller) driver.
 *
 * The PC has two cascaded 8259 PICs, each handling 8 IRQ lines. By
 * default (post-BIOS-init) IRQ0-7 map to interrupt vectors 8-15 and
 * IRQ8-15 map to 0x70-0x77 - both of which collide with CPU exception
 * vectors (0-31) or are otherwise inconvenient. We remap them to
 * vectors 32-47 (0x20-0x2F), which is free and conventional.
 */

#include "pic.h"
#include "ports.h"

#define PIC1_COMMAND 0x20
#define PIC1_DATA    0x21
#define PIC2_COMMAND 0xA0
#define PIC2_DATA    0xA1

#define ICW1_INIT    0x10
#define ICW1_ICW4    0x01
#define ICW4_8086    0x01

#define PIC1_VECTOR_OFFSET 0x20  /* IRQ0-7  -> vectors 32-39 */
#define PIC2_VECTOR_OFFSET 0x28  /* IRQ8-15 -> vectors 40-47 */

void pic_remap(void) {
    unsigned char mask1 = inb(PIC1_DATA);
    unsigned char mask2 = inb(PIC2_DATA);

    /* Start initialization sequence (cascade mode) on both PICs */
    outb(PIC1_COMMAND, ICW1_INIT | ICW1_ICW4);
    outb(PIC2_COMMAND, ICW1_INIT | ICW1_ICW4);

    /* ICW2: vector offsets */
    outb(PIC1_DATA, PIC1_VECTOR_OFFSET);
    outb(PIC2_DATA, PIC2_VECTOR_OFFSET);

    /* ICW3: tell PIC1 there's a slave PIC at IRQ2 (0000 0100),
       tell PIC2 its cascade identity (0000 0010) */
    outb(PIC1_DATA, 0x04);
    outb(PIC2_DATA, 0x02);

    /* ICW4: 8086 mode */
    outb(PIC1_DATA, ICW4_8086);
    outb(PIC2_DATA, ICW4_8086);

    /* Restore saved interrupt masks rather than assuming all-unmasked,
       so we don't enable IRQ lines nothing is prepared to handle yet. */
    outb(PIC1_DATA, mask1);
    outb(PIC2_DATA, mask2);
}

void pic_send_eoi(unsigned char irq) {
    /* If the IRQ came from the slave PIC (IRQ 8-15), both PICs need
       an End-Of-Interrupt; the master always needs one. */
    if (irq >= 8) {
        outb(PIC2_COMMAND, 0x20);
    }
    outb(PIC1_COMMAND, 0x20);
}

void pic_set_mask(unsigned char irq) {
    unsigned short port = (irq < 8) ? PIC1_DATA : PIC2_DATA;
    unsigned char irq_line = (irq < 8) ? irq : irq - 8;
    unsigned char value = inb(port) | (1 << irq_line);
    outb(port, value);
}

void pic_clear_mask(unsigned char irq) {
    unsigned short port = (irq < 8) ? PIC1_DATA : PIC2_DATA;
    unsigned char irq_line = (irq < 8) ? irq : irq - 8;
    unsigned char value = inb(port) & ~(1 << irq_line);
    outb(port, value);
}
