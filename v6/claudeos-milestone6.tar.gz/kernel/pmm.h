#ifndef CLAUDEOS_PMM_H
#define CLAUDEOS_PMM_H

void pmm_init(void);
unsigned int pmm_alloc_page(void);      /* returns physical address, or 0 on failure */
void pmm_free_page(unsigned int physical_addr);
unsigned int pmm_free_frame_count(void);
unsigned int pmm_total_frame_count(void);

#endif
