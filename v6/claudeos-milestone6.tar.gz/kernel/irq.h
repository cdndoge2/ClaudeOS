#ifndef CLAUDEOS_IRQ_H
#define CLAUDEOS_IRQ_H

typedef void (*irq_handler_t)(void);

void irq_install_all(void);
void irq_register_handler(int irq, irq_handler_t handler);

#endif
