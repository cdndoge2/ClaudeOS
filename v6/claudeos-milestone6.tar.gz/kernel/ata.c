/*
 * ATA PIO disk driver - primary bus, master drive, 28-bit LBA mode,
 * multi-sector transfers.
 *
 * Talks to the same disk image the BIOS boot chain loaded from
 * (QEMU's -drive raw image is this same ATA device), via direct port
 * I/O since BIOS interrupts aren't usable once we're in protected
 * mode. Polls status registers and blocks - no IRQ-driven DMA - which
 * is simple and entirely adequate for a single-tasking hobby OS doing
 * small, infrequent transfers.
 *
 * Multi-sector transfers issue ONE command for the whole run (sector
 * count register set to `count`), but DRQ (data request) asserts once
 * per sector, not once for the whole transfer - so the wait-for-DRQ
 * check has to happen inside the per-sector loop, not just once before
 * it. Getting this wrong (checking DRQ once, then reading count
 * sectors' worth of words) is a classic ATA PIO bug that "mostly
 * works" for count=1 but corrupts data on multi-sector reads/writes -
 * worth calling out explicitly since it's easy to get subtly wrong.
 */

#include "ata.h"
#include "ports.h"

#define ATA_DATA        0x1F0
#define ATA_SECCOUNT    0x1F2
#define ATA_LBA_LOW     0x1F3
#define ATA_LBA_MID     0x1F4
#define ATA_LBA_HIGH    0x1F5
#define ATA_DRIVE_HEAD  0x1F6
#define ATA_STATUS      0x1F7
#define ATA_COMMAND     0x1F7

#define ATA_CMD_READ    0x20
#define ATA_CMD_WRITE   0x30
#define ATA_CMD_FLUSH   0xE7

#define ATA_STATUS_ERR  0x01
#define ATA_STATUS_DRQ  0x08
#define ATA_STATUS_BSY  0x80

static void ata_wait_not_busy(void) {
    while (inb(ATA_STATUS) & ATA_STATUS_BSY) {
        /* busy-poll - fine with no multitasking to preempt into instead */
    }
}

static int ata_wait_drq(void) {
    unsigned char status;
    do {
        status = inb(ATA_STATUS);
        if (status & ATA_STATUS_ERR) {
            return -1;
        }
    } while (!(status & ATA_STATUS_DRQ));
    return 0;
}

static void ata_select_and_setup(unsigned int lba, unsigned char count) {
    /* 0xE0 = LBA mode + master drive; top 4 bits of a 28-bit LBA go in
       the low nibble of this register. */
    outb(ATA_DRIVE_HEAD, (unsigned char)(0xE0 | ((lba >> 24) & 0x0F)));
    outb(ATA_SECCOUNT, count);
    outb(ATA_LBA_LOW,  (unsigned char)(lba & 0xFF));
    outb(ATA_LBA_MID,  (unsigned char)((lba >> 8) & 0xFF));
    outb(ATA_LBA_HIGH, (unsigned char)((lba >> 16) & 0xFF));
}

int ata_read_sectors(unsigned int lba, unsigned char count, void *buffer) {
    if (count == 0) {
        return 0;
    }

    ata_wait_not_busy();
    ata_select_and_setup(lba, count);
    outb(ATA_COMMAND, ATA_CMD_READ);

    unsigned char *buf = (unsigned char *)buffer;
    for (int s = 0; s < count; s++) {
        if (ata_wait_drq() != 0) {
            return -1;
        }
        unsigned short *dst = (unsigned short *)(buf + (s * 512));
        for (int i = 0; i < 256; i++) {
            dst[i] = inw(ATA_DATA);
        }
    }
    return 0;
}

int ata_write_sectors(unsigned int lba, unsigned char count, const void *buffer) {
    if (count == 0) {
        return 0;
    }

    ata_wait_not_busy();
    ata_select_and_setup(lba, count);
    outb(ATA_COMMAND, ATA_CMD_WRITE);

    const unsigned char *buf = (const unsigned char *)buffer;
    for (int s = 0; s < count; s++) {
        if (ata_wait_drq() != 0) {
            return -1;
        }
        const unsigned short *src = (const unsigned short *)(buf + (s * 512));
        for (int i = 0; i < 256; i++) {
            outw(ATA_DATA, src[i]);
            io_wait();
        }
    }

    /* Flush the write cache so data is actually persisted rather than
       sitting in a volatile cache - the entire point of "persistent"
       storage depends on this actually happening. */
    ata_wait_not_busy();
    outb(ATA_COMMAND, ATA_CMD_FLUSH);
    ata_wait_not_busy();

    return 0;
}
