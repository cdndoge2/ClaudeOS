/*
 * Physical memory manager.
 *
 * Tracks 4KB page frames with a bitmap (1 bit per frame: 0 = free,
 * 1 = used/reserved). Built from the E820 memory map stage2 left at a
 * fixed address (see e820.h). This is deliberately simple - no buddy
 * allocator, no NUMA awareness, no support for memory above 4GB (we're
 * 32-bit with no PAE) - appropriate for a sub-512KB hobby OS.
 *
 * Coverage cap: we support up to PMM_MAX_MEMORY (256MB) regardless of
 * how much RAM E820 reports. This lets the bitmap be a fixed-size
 * static array (no dynamic sizing, which would need a working
 * allocator before the allocator exists - a chicken-and-egg problem
 * not worth solving for a hobby project). 256MB is far more than this
 * OS needs, and QEMU/Bochs/real hardware all commonly report more than
 * that as available, so the cap just means "we ignore anything above
 * 256MB" rather than failing.
 */

#include "pmm.h"
#include "e820.h"

#define PAGE_SIZE 4096
#define PMM_MAX_MEMORY (256u * 1024u * 1024u)
#define PMM_MAX_FRAMES (PMM_MAX_MEMORY / PAGE_SIZE)
#define PMM_BITMAP_BYTES (PMM_MAX_FRAMES / 8)

/* Reserve the entire first 1MB unconditionally, regardless of what
   E820 claims about it. This is where real-mode structures (IVT,
   BDA), our bootloader stages, the VGA text buffer (0xB8000), and -
   importantly - our own kernel (loaded at 0x10000) all live. Treating
   this whole range as "already in use" is simpler and safer than
   trying to carve out exactly the parts we occupy. */
#define RESERVED_LOW_MEMORY (1024u * 1024u)

static unsigned char bitmap[PMM_BITMAP_BYTES];
static unsigned int total_free_frames = 0;
static unsigned int highest_usable_frame = 0;

static inline void bitmap_set(unsigned int frame) {
    bitmap[frame / 8] |= (unsigned char)(1 << (frame % 8));
}
static inline void bitmap_clear(unsigned int frame) {
    bitmap[frame / 8] &= (unsigned char)~(1 << (frame % 8));
}
static inline int bitmap_test(unsigned int frame) {
    return (bitmap[frame / 8] >> (frame % 8)) & 1;
}

void pmm_init(void) {
    /* Default: everything marked used. We only clear bits for memory
       E820 explicitly reports as usable - safer than assuming
       anything is free by default. */
    for (unsigned int i = 0; i < PMM_BITMAP_BYTES; i++) {
        bitmap[i] = 0xFF;
    }
    total_free_frames = 0;
    highest_usable_frame = 0;

    unsigned int count = *(volatile unsigned int *)E820_COUNT_ADDR;
    struct e820_entry *entries = (struct e820_entry *)E820_ENTRIES_ADDR;

    for (unsigned int i = 0; i < count; i++) {
        struct e820_entry *e = &entries[i];

        /* Ignore any region at or above 4GB (base_high != 0) - we
           have no way to address it as a 32-bit OS without PAE. */
        if (e->type != E820_TYPE_USABLE || e->base_high != 0) {
            continue;
        }

        unsigned int base = e->base_low;
        unsigned int length = e->length_low;
        if (length == 0) {
            continue;
        }

        unsigned int end = base + length;
        if (end < base) {
            end = 0xFFFFFFFF; /* overflow guard - clamp rather than wrap */
        }
        if (end > PMM_MAX_MEMORY) {
            end = PMM_MAX_MEMORY;
        }
        if (base >= end) {
            continue;
        }

        unsigned int start_frame = base / PAGE_SIZE;
        unsigned int end_frame = end / PAGE_SIZE;

        for (unsigned int frame = start_frame; frame < end_frame; frame++) {
            if (bitmap_test(frame)) {
                bitmap_clear(frame);
                total_free_frames++;
            }
            if (frame > highest_usable_frame) {
                highest_usable_frame = frame;
            }
        }
    }

    /* Now unconditionally re-reserve the first 1MB, overriding
       whatever E820 said about it (some BIOSes report parts of low
       memory as "usable" even though real-mode structures and our own
       code live there). */
    unsigned int reserved_frames = RESERVED_LOW_MEMORY / PAGE_SIZE;
    for (unsigned int frame = 0; frame < reserved_frames; frame++) {
        if (!bitmap_test(frame)) {
            bitmap_set(frame);
            total_free_frames--;
        }
    }
}

unsigned int pmm_alloc_page(void) {
    for (unsigned int frame = 0; frame <= highest_usable_frame; frame++) {
        if (!bitmap_test(frame)) {
            bitmap_set(frame);
            total_free_frames--;
            return frame * PAGE_SIZE;
        }
    }
    return 0; /* 0 is never a valid allocation (it's inside the reserved
                 first 1MB), so it doubles as a failure sentinel */
}

void pmm_free_page(unsigned int physical_addr) {
    unsigned int frame = physical_addr / PAGE_SIZE;
    if (frame > highest_usable_frame) {
        return; /* out of range - ignore rather than corrupt the bitmap */
    }
    if (bitmap_test(frame)) {
        bitmap_clear(frame);
        total_free_frames++;
    }
}

unsigned int pmm_free_frame_count(void) {
    return total_free_frames;
}

unsigned int pmm_total_frame_count(void) {
    return highest_usable_frame + 1;
}
