#ifndef CLAUDEOS_FS_H
#define CLAUDEOS_FS_H

#define FS_MAX_FILES 16
#define FS_NAME_LEN  27   /* + 1 null terminator = 28 bytes on disk */
#define FS_MAX_FILE_SIZE (16 * 512) /* 16 sectors = 8KB per file */

void fs_init(void);

/* Creates the file if it doesn't exist, or overwrites it if it does.
   Returns 0 on success, -1 on failure (name too long, file too large,
   or no free slot and no existing file to overwrite). */
int fs_write(const char *name, const void *data, unsigned int size);

/* Reads up to max_len-1 bytes into out_buf and null-terminates it
   (this filesystem is oriented around small text files - notepad,
   config-style data - not arbitrary binary blobs, so this text-
   friendly convenience is a deliberate design choice, not an
   oversight). Returns the number of bytes copied (excluding the null
   terminator), or -1 if the file doesn't exist. */
int fs_read(const char *name, char *out_buf, unsigned int max_len);

/* Returns 0 on success, -1 if the file doesn't exist. */
int fs_delete(const char *name);

/* Iterates filesystem slots 0..FS_MAX_FILES-1. Returns 1 and fills
   name_out (buffer of at least FS_NAME_LEN+1 bytes) and size_out if
   the slot is in use, 0 if the slot is free or the index is out of
   range. Used by the shell's `ls` command. */
int fs_get_slot_info(int slot_index, char *name_out, unsigned int *size_out);

#endif
