/*
 * ClaudeFS - a deliberately simple flat filesystem.
 *
 * No directories, no free-space bitmap for file data, no variable-size
 * allocation: a fixed number of file-table slots (FS_MAX_FILES), each
 * mapped to a fixed-size, fixed-location data region on disk
 * (slot index determines its data LBA directly - see fs_write). This
 * trades flexibility (max 16 files, max 8KB each) for a filesystem
 * simple enough to implement and debug correctly in one sitting, which
 * matters more than generality for this project's scope. A real
 * filesystem's variable-length extents and free-space tracking are a
 * meaningfully bigger feature, deliberately deferred rather than
 * half-implemented.
 *
 * On-disk layout (LBA = sector number):
 *   FS_START_LBA            : superblock (1 sector)
 *   FS_START_LBA+1          : file table (FILE_TABLE_SECTORS sectors)
 *   sb.data_start_lba        : file data, FS_MAX_FILES slots of
 *                              sb.max_file_sectors sectors each
 *
 * The whole file table is cached in memory and rewritten to disk in
 * full on every create/write/delete - simple, and cheap enough at this
 * scale (2 sectors) that there's no reason to do partial updates.
 */

#include "fs.h"
#include "ata.h"
#include "kstring.h"

/* Must match the disk image layout reserved in the Makefile - see the
   FS_START_LBA/FS_SECTOR_COUNT variables there. Same fixed-constant
   cross-file dependency pattern as the E820 addresses in e820.h. */
#define FS_START_LBA 200

#define FS_MAGIC 0x43465331u /* 'CFS1' */

struct file_entry {
    char name[FS_NAME_LEN + 1];
    unsigned char used;
    unsigned char reserved[3];
    unsigned int size;
    unsigned int start_lba;
} __attribute__((packed));

#define FILE_TABLE_BYTES (FS_MAX_FILES * sizeof(struct file_entry))
#define FILE_TABLE_SECTORS ((FILE_TABLE_BYTES + 511) / 512)

struct superblock {
    unsigned int magic;
    unsigned int max_files;
    unsigned int max_file_sectors;
    unsigned int file_table_lba;
    unsigned int file_table_sectors;
    unsigned int data_start_lba;
} __attribute__((packed));

static struct superblock sb;
static struct file_entry table[FS_MAX_FILES];
static unsigned char io_buf[FS_MAX_FILE_SIZE]; /* reused staging buffer for
                                                    whole-slot read/write -
                                                    safe since the kernel
                                                    is single-threaded */

static void write_superblock(void) {
    unsigned char buf[512];
    kmemset(buf, 0, sizeof(buf));
    kmemcpy(buf, &sb, sizeof(sb));
    ata_write_sectors(FS_START_LBA, 1, buf);
}

static void write_table(void) {
    static unsigned char buf[FILE_TABLE_SECTORS * 512];
    kmemset(buf, 0, sizeof(buf));
    kmemcpy(buf, table, sizeof(table));
    ata_write_sectors(sb.file_table_lba, (unsigned char)FILE_TABLE_SECTORS, buf);
}

static void load_table(void) {
    static unsigned char buf[FILE_TABLE_SECTORS * 512];
    ata_read_sectors(sb.file_table_lba, (unsigned char)FILE_TABLE_SECTORS, buf);
    kmemcpy(table, buf, sizeof(table));
}

static void format_filesystem(void) {
    sb.magic = FS_MAGIC;
    sb.max_files = FS_MAX_FILES;
    sb.max_file_sectors = FS_MAX_FILE_SIZE / 512;
    sb.file_table_lba = FS_START_LBA + 1;
    sb.file_table_sectors = FILE_TABLE_SECTORS;
    sb.data_start_lba = sb.file_table_lba + sb.file_table_sectors;

    kmemset(table, 0, sizeof(table));

    write_superblock();
    write_table();
}

void fs_init(void) {
    unsigned char buf[512];
    ata_read_sectors(FS_START_LBA, 1, buf);
    kmemcpy(&sb, buf, sizeof(sb));

    if (sb.magic != FS_MAGIC) {
        /* No valid filesystem found - this is expected on the very
           first boot against a fresh disk image (the reserved region
           is zero-filled, so the magic check fails), and also acts as
           a safety net if the region ever gets corrupted. Either way,
           the right move is the same: lay down a fresh, empty
           filesystem rather than trying to interpret garbage. */
        format_filesystem();
    } else {
        load_table();
    }
}

static int find_slot(const char *name) {
    for (int i = 0; i < FS_MAX_FILES; i++) {
        if (table[i].used && kstrcmp(table[i].name, name) == 0) {
            return i;
        }
    }
    return -1;
}

static int find_free_slot(void) {
    for (int i = 0; i < FS_MAX_FILES; i++) {
        if (!table[i].used) {
            return i;
        }
    }
    return -1;
}

int fs_write(const char *name, const void *data, unsigned int size) {
    int namelen = kstrlen(name);
    if (namelen == 0 || namelen > FS_NAME_LEN) {
        return -1;
    }
    if (size > FS_MAX_FILE_SIZE) {
        return -1;
    }

    int idx = find_slot(name);
    if (idx < 0) {
        idx = find_free_slot();
        if (idx < 0) {
            return -1; /* filesystem full */
        }
    }

    kmemset(table[idx].name, 0, sizeof(table[idx].name));
    kmemcpy(table[idx].name, name, (unsigned int)namelen);
    table[idx].used = 1;
    table[idx].size = size;
    table[idx].start_lba = sb.data_start_lba + (unsigned int)idx * sb.max_file_sectors;

    kmemset(io_buf, 0, sizeof(io_buf));
    kmemcpy(io_buf, data, size);

    if (ata_write_sectors(table[idx].start_lba, (unsigned char)sb.max_file_sectors, io_buf) != 0) {
        return -1;
    }

    write_table();
    return 0;
}

int fs_read(const char *name, char *out_buf, unsigned int max_len) {
    if (max_len == 0) {
        return -1;
    }

    int idx = find_slot(name);
    if (idx < 0) {
        return -1;
    }

    if (ata_read_sectors(table[idx].start_lba, (unsigned char)sb.max_file_sectors, io_buf) != 0) {
        return -1;
    }

    unsigned int copy_len = table[idx].size;
    if (copy_len > max_len - 1) {
        copy_len = max_len - 1;
    }
    kmemcpy(out_buf, io_buf, copy_len);
    out_buf[copy_len] = '\0';
    return (int)copy_len;
}

int fs_delete(const char *name) {
    int idx = find_slot(name);
    if (idx < 0) {
        return -1;
    }
    table[idx].used = 0;
    table[idx].size = 0;
    write_table();
    return 0;
}

int fs_get_slot_info(int slot_index, char *name_out, unsigned int *size_out) {
    if (slot_index < 0 || slot_index >= FS_MAX_FILES) {
        return 0;
    }
    if (!table[slot_index].used) {
        return 0;
    }
    kmemcpy(name_out, table[slot_index].name, sizeof(table[slot_index].name));
    *size_out = table[slot_index].size;
    return 1;
}
