#include "kstring.h"

int kstrlen(const char *s) {
    int len = 0;
    while (s[len] != '\0') len++;
    return len;
}

int kstrcmp(const char *a, const char *b) {
    while (*a != '\0' && *a == *b) {
        a++;
        b++;
    }
    return (unsigned char)*a - (unsigned char)*b;
}

int kstrncmp(const char *a, const char *b, int n) {
    for (int i = 0; i < n; i++) {
        if (a[i] != b[i] || a[i] == '\0') {
            return (unsigned char)a[i] - (unsigned char)b[i];
        }
    }
    return 0;
}

void kstrncpy(char *dst, const char *src, int max_len) {
    int i = 0;
    for (; i < max_len - 1 && src[i] != '\0'; i++) {
        dst[i] = src[i];
    }
    dst[i] = '\0';
}

void *kmemcpy(void *dest, const void *src, unsigned int n) {
    unsigned char *d = (unsigned char *)dest;
    const unsigned char *s = (const unsigned char *)src;
    for (unsigned int i = 0; i < n; i++) {
        d[i] = s[i];
    }
    return dest;
}

void *kmemset(void *dest, int value, unsigned int n) {
    unsigned char *d = (unsigned char *)dest;
    for (unsigned int i = 0; i < n; i++) {
        d[i] = (unsigned char)value;
    }
    return dest;
}
