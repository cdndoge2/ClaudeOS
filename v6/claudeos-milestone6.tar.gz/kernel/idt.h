#ifndef CLAUDEOS_IDT_H
#define CLAUDEOS_IDT_H

void idt_install(void);
void idt_set_handler(int num, unsigned int handler);

#endif
