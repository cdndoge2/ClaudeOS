/*
 * ClaudeOS main menu.
 *
 * The top-level UI: a numbered list of apps and games. Reads a choice,
 * launches the corresponding app/game, and redraws the menu when it
 * returns. The raw command shell is still here too (as "Terminal") -
 * it's more powerful for anything not covered by a dedicated app
 * (there's no menu entry for `echo` or `meminfo`, for instance), so
 * removing it in favor of a purely menu-driven interface would be a
 * step backward, not forward.
 *
 * Each menu action gets its own small wrapper function here (prompt
 * for whatever input the app needs, call the shared app_* function
 * from shell.c, wait for Enter before returning to the menu) rather
 * than baking menu-specific UI into shell.c itself - keeps shell.c
 * focused on "do the thing" and menu.c focused on "ask what to do and
 * present the result," which matters once more apps/games arrive and
 * this file's list of wrappers grows.
 */

#include "menu.h"
#include "vga.h"
#include "keyboard.h"
#include "kstring.h"
#include "shell.h"
#include "fs.h"
#include "tictactoe.h"

#define INPUT_BUFFER_SIZE 64

static void wait_for_enter(void) {
    term_print("\nPress Enter to return to the menu...");
    char dummy[8];
    keyboard_read_line(dummy, sizeof(dummy));
}

static void not_implemented_yet(const char *name) {
    term_print("\n");
    term_print(name);
    term_print(" isn't implemented yet - coming in a future milestone.\n");
    wait_for_enter();
}

/* ---- Menu wrappers around shell.c's shared app_* functions ---- */

static void menu_notepad(void) {
    term_clear();
    term_print("=== Notepad ===\n\n");
    term_print("Enter filename: ");
    char name[FS_NAME_LEN + 1];
    keyboard_read_line(name, sizeof(name));
    if (kstrlen(name) == 0) {
        term_print("Cancelled.\n");
        wait_for_enter();
        return;
    }
    term_print("\n");
    app_notepad(name); /* app_notepad has its own save/discard prompt loop */
}

static void menu_calculator(void) {
    term_clear();
    term_print("=== Calculator ===\n\n");
    term_print("Enter an expression, e.g. \"5 + 3\": ");
    char line[INPUT_BUFFER_SIZE];
    keyboard_read_line(line, sizeof(line));
    term_print("\nResult: ");
    app_calc(line);
    wait_for_enter();
}

static void menu_sysinfo(void) {
    term_clear();
    app_sysinfo();
    wait_for_enter();
}

/* A small interactive loop around the shared file-management
   functions (app_ls/app_cat/app_rm) - lists files, lets the user pick
   one to view and optionally delete, and repeats until they choose to
   go back. This is UI logic specific to the menu, which is why it
   lives here rather than as another shell.c app_* function - the raw
   shell already has ls/cat/rm as separate one-shot commands, which
   suits command-line use better than a guided loop would. */
static void menu_file_manager(void) {
    for (;;) {
        term_clear();
        term_print("=== File Manager ===\n\n");
        app_ls();
        term_print("\nEnter a filename to view (blank to go back): ");

        char name[FS_NAME_LEN + 1];
        keyboard_read_line(name, sizeof(name));
        if (kstrlen(name) == 0) {
            return;
        }

        term_print("\n");
        app_cat(name);

        term_print("\nDelete this file? (y/N): ");
        char answer[8];
        keyboard_read_line(answer, sizeof(answer));
        if (answer[0] == 'y' || answer[0] == 'Y') {
            app_rm(name);
        }

        wait_for_enter();
    }
}

static void menu_terminal(void) {
    term_clear();
    shell_run(); /* returns when the user types 'exit' */
}

/* ---- Menu display and dispatch ---- */

static void print_menu(void) {
    term_clear();
    term_print("=== ClaudeOS Main Menu ===\n");
    term_print("Milestone 6: TUI + games\n\n");

    term_print("=== Apps ===\n");
    term_print("  1. Notepad\n");
    term_print("  2. Calculator\n");
    term_print("  3. File Manager\n");
    term_print("  4. System Info\n");
    term_print("  5. Terminal (full command shell)\n\n");

    term_print("=== Games ===\n");
    term_print("  6. Tic-Tac-Toe\n");
    term_print("  7. Minesweeper (coming soon)\n");
    term_print("  8. Blackjack (coming soon)\n");
    term_print("  9. Pong (coming soon)\n");
    term_print(" 10. Snake (coming soon)\n");
    term_print(" 11. Tetris (coming soon)\n");
    term_print(" 12. 2048 (coming soon)\n\n");

    term_print("  0. Reboot\n\n");
    term_print("Enter choice: ");
}

/* Hand-rolled non-negative integer parse - same pattern as shell.c's
   calculator parser, kept separate since this one has no sign and a
   different error contract (a bool-ish "did this parse" rather than
   feeding into arithmetic). */
static int parse_choice(const char *s, int *out) {
    if (kstrlen(s) == 0) {
        return -1;
    }
    int value = 0;
    for (int i = 0; s[i] != '\0'; i++) {
        if (s[i] < '0' || s[i] > '9') {
            return -1;
        }
        value = value * 10 + (s[i] - '0');
    }
    *out = value;
    return 0;
}

void menu_run(void) {
    for (;;) {
        print_menu();

        char line[INPUT_BUFFER_SIZE];
        keyboard_read_line(line, sizeof(line));

        int choice;
        if (parse_choice(line, &choice) != 0) {
            term_print("\nInvalid choice.\n");
            wait_for_enter();
            continue;
        }

        switch (choice) {
            case 1: menu_notepad(); break;
            case 2: menu_calculator(); break;
            case 3: menu_file_manager(); break;
            case 4: menu_sysinfo(); break;
            case 5: menu_terminal(); break;
            case 6: game_tictactoe(); break;
            case 7: not_implemented_yet("Minesweeper"); break;
            case 8: not_implemented_yet("Blackjack"); break;
            case 9: not_implemented_yet("Pong"); break;
            case 10: not_implemented_yet("Snake"); break;
            case 11: not_implemented_yet("Tetris"); break;
            case 12: not_implemented_yet("2048"); break;
            case 0: app_reboot(); break;
            default:
                term_print("\nInvalid choice.\n");
                wait_for_enter();
                break;
        }
    }
}
