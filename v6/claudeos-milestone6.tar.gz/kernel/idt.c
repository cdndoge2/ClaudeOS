/*
 * Interrupt Descriptor Table (IDT) setup.
 *
 * The IDT tells the CPU where to jump for each of the 256 possible
 * interrupt/exception vectors: 0-31 are CPU exceptions (divide error,
 * page fault, etc.), 32-255 are free for hardware IRQs and software
 * interrupts. We remap the PIC (see pic.c) so hardware IRQs land at
 * 32-47, avoiding collision with the CPU exception range - a classic
 * early-OS bug if skipped (IRQ0 would otherwise fire on vector 8, which
 * is the double-fault exception).
 */

#include "idt.h"

/* Each gate is 8 bytes: offset_low(2), selector(2), zero(1), type_attr(1), offset_high(2) */
struct idt_entry {
    unsigned short offset_low;
    unsigned short selector;
    unsigned char  zero;
    unsigned char  type_attr;
    unsigned short offset_high;
} __attribute__((packed));

struct idt_ptr {
    unsigned short limit;
    unsigned int   base;
} __attribute__((packed));

#define IDT_ENTRIES 256

static struct idt_entry idt[IDT_ENTRIES];
static struct idt_ptr   idtp;

/* Defined in idt_load.S - loads the IDT register via `lidt` */
extern void idt_load(unsigned int idt_ptr_addr);

static void idt_set_gate(int num, unsigned int handler, unsigned short selector, unsigned char type_attr) {
    idt[num].offset_low  = (unsigned short)(handler & 0xFFFF);
    idt[num].offset_high = (unsigned short)((handler >> 16) & 0xFFFF);
    idt[num].selector    = selector;
    idt[num].zero        = 0;
    idt[num].type_attr   = type_attr;
}

void idt_install(void) {
    idtp.limit = (sizeof(struct idt_entry) * IDT_ENTRIES) - 1;
    idtp.base  = (unsigned int)&idt;

    /* Zero the whole table first so any vector we don't explicitly
       install has a predictable (empty) entry rather than garbage. */
    for (int i = 0; i < IDT_ENTRIES; i++) {
        idt_set_gate(i, 0, 0, 0);
    }

    idt_load((unsigned int)&idtp);
}

/* Exposed so isr.c and irq.c can install their handler stubs into
   specific vector numbers without duplicating the gate-encoding logic. */
void idt_set_handler(int num, unsigned int handler) {
    /* selector 0x08 = our kernel code segment (see boot/stage2.S GDT);
       type_attr 0x8E = present, ring0, 32-bit interrupt gate */
    idt_set_gate(num, handler, 0x08, 0x8E);
}
