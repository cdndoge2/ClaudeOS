#ifndef CLAUDEOS_ISR_H
#define CLAUDEOS_ISR_H

void isr_install_all(void);

#endif
