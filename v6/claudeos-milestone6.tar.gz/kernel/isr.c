#include "idt.h"
#include "vga.h"

/*
 * Declare the 32 assembly ISR stub entry points (defined in isr.S).
 * Each is just a label/address at this point - idt_install_isrs wires
 * them into the IDT.
 */
#define DECLARE_ISR(n) extern void isr##n(void);
DECLARE_ISR(0)  DECLARE_ISR(1)  DECLARE_ISR(2)  DECLARE_ISR(3)
DECLARE_ISR(4)  DECLARE_ISR(5)  DECLARE_ISR(6)  DECLARE_ISR(7)
DECLARE_ISR(8)  DECLARE_ISR(9)  DECLARE_ISR(10) DECLARE_ISR(11)
DECLARE_ISR(12) DECLARE_ISR(13) DECLARE_ISR(14) DECLARE_ISR(15)
DECLARE_ISR(16) DECLARE_ISR(17) DECLARE_ISR(18) DECLARE_ISR(19)
DECLARE_ISR(20) DECLARE_ISR(21) DECLARE_ISR(22) DECLARE_ISR(23)
DECLARE_ISR(24) DECLARE_ISR(25) DECLARE_ISR(26) DECLARE_ISR(27)
DECLARE_ISR(28) DECLARE_ISR(29) DECLARE_ISR(30) DECLARE_ISR(31)

/* Must match the register push order in isr.S's isr_common_stub:
   pushal order (edi,esi,ebp,esp,ebx,edx,ecx,eax), then ds, then
   vector/errcode/eip/cs/eflags pushed earlier (CPU + our stub). */
struct isr_frame {
    unsigned int ds;
    unsigned int edi, esi, ebp, esp_dummy, ebx, edx, ecx, eax;
    unsigned int vector, error_code;
    unsigned int eip, cs, eflags;
};

static const char *exception_names[32] = {
    "Divide-by-zero", "Debug", "Non-maskable interrupt", "Breakpoint",
    "Overflow", "Bound range exceeded", "Invalid opcode", "Device not available",
    "Double fault", "Coprocessor segment overrun", "Invalid TSS", "Segment not present",
    "Stack-segment fault", "General protection fault", "Page fault", "Reserved",
    "x87 floating point exception", "Alignment check", "Machine check", "SIMD floating point exception",
    "Virtualization exception", "Reserved", "Reserved", "Reserved",
    "Reserved", "Reserved", "Reserved", "Reserved",
    "Reserved", "Reserved", "Reserved", "Reserved"
};

/*
 * isr_common_handler: called from the assembly trampoline for every
 * CPU exception. For now this is a "panic" handler - we have no
 * process model yet, so any exception is fatal. It prints diagnostics
 * (which exception, error code, faulting EIP) and halts, which is far
 * more useful for debugging than a silent triple-fault/reboot.
 */
void isr_common_handler(struct isr_frame *frame) {
    vga_panic_screen();
    vga_print_at("*** ClaudeOS EXCEPTION ***", 0, 0);

    const char *name = "Unknown";
    if (frame->vector < 32) {
        name = exception_names[frame->vector];
    }
    vga_print_at(name, 1, 0);

    vga_print_kv("Vector",     frame->vector,     3, 0);
    vga_print_kv("Error code", frame->error_code,  4, 0);
    vga_print_kv("EIP",        frame->eip,         5, 0);
    vga_print_kv("CS",         frame->cs,          6, 0);
    vga_print_kv("EFLAGS",     frame->eflags,      7, 0);

    for (;;) {
        __asm__ volatile ("cli; hlt");
    }
}

void isr_install_all(void) {
    idt_set_handler(0,  (unsigned int)isr0);
    idt_set_handler(1,  (unsigned int)isr1);
    idt_set_handler(2,  (unsigned int)isr2);
    idt_set_handler(3,  (unsigned int)isr3);
    idt_set_handler(4,  (unsigned int)isr4);
    idt_set_handler(5,  (unsigned int)isr5);
    idt_set_handler(6,  (unsigned int)isr6);
    idt_set_handler(7,  (unsigned int)isr7);
    idt_set_handler(8,  (unsigned int)isr8);
    idt_set_handler(9,  (unsigned int)isr9);
    idt_set_handler(10, (unsigned int)isr10);
    idt_set_handler(11, (unsigned int)isr11);
    idt_set_handler(12, (unsigned int)isr12);
    idt_set_handler(13, (unsigned int)isr13);
    idt_set_handler(14, (unsigned int)isr14);
    idt_set_handler(15, (unsigned int)isr15);
    idt_set_handler(16, (unsigned int)isr16);
    idt_set_handler(17, (unsigned int)isr17);
    idt_set_handler(18, (unsigned int)isr18);
    idt_set_handler(19, (unsigned int)isr19);
    idt_set_handler(20, (unsigned int)isr20);
    idt_set_handler(21, (unsigned int)isr21);
    idt_set_handler(22, (unsigned int)isr22);
    idt_set_handler(23, (unsigned int)isr23);
    idt_set_handler(24, (unsigned int)isr24);
    idt_set_handler(25, (unsigned int)isr25);
    idt_set_handler(26, (unsigned int)isr26);
    idt_set_handler(27, (unsigned int)isr27);
    idt_set_handler(28, (unsigned int)isr28);
    idt_set_handler(29, (unsigned int)isr29);
    idt_set_handler(30, (unsigned int)isr30);
    idt_set_handler(31, (unsigned int)isr31);
}
