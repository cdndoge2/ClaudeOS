#ifndef CLAUDEOS_KMALLOC_H
#define CLAUDEOS_KMALLOC_H

void kheap_init(void);
void *kmalloc(unsigned int size);
void kfree(void *ptr);
unsigned int kheap_total_bytes(void);
unsigned int kheap_free_bytes(void);

#endif
