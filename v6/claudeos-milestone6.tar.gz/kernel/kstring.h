#ifndef CLAUDEOS_KSTRING_H
#define CLAUDEOS_KSTRING_H

int kstrlen(const char *s);
int kstrcmp(const char *a, const char *b);
int kstrncmp(const char *a, const char *b, int n);
void kstrncpy(char *dst, const char *src, int max_len);
void *kmemcpy(void *dest, const void *src, unsigned int n);
void *kmemset(void *dest, int value, unsigned int n);

#endif
