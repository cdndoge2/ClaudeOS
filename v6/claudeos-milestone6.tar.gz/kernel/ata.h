#ifndef CLAUDEOS_ATA_H
#define CLAUDEOS_ATA_H

/* Both return 0 on success, -1 on drive-reported error. buffer must be
   at least count*512 bytes. */
int ata_read_sectors(unsigned int lba, unsigned char count, void *buffer);
int ata_write_sectors(unsigned int lba, unsigned char count, const void *buffer);

#endif
