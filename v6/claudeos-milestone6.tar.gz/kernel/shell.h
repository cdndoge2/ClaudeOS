#ifndef CLAUDEOS_SHELL_H
#define CLAUDEOS_SHELL_H

/* shell_run() is the raw command-line loop - runs until the user
   types 'exit', then returns (used as the menu's "Terminal" option,
   not the only way into the system anymore). */
void shell_run(void);

/* App entry points, also reachable as shell commands - exposed here
   so kernel/menu.c can launch them directly without going through
   command-line parsing. Single implementation, two ways in. */
void app_notepad(const char *filename);
void app_calc(const char *args);
void app_sysinfo(void);
void app_ls(void);
void app_cat(const char *name);
void app_rm(const char *name);
void app_write(const char *args);
void app_reboot(void);

#endif
