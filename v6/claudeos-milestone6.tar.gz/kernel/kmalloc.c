/*
 * Kernel heap allocator (kmalloc/kfree).
 *
 * A simple first-fit, singly-linked free list over a fixed-size heap
 * region. The heap itself is carved out at boot by requesting
 * KHEAP_PAGES consecutive pages from the physical memory manager.
 *
 * "Consecutive" is an assumption, not a guarantee from pmm_alloc_page()
 * in general - but since kheap_init() runs once, early in boot, before
 * anything else has allocated a single page, and pmm's bitmap scan
 * always returns the lowest-numbered free frame, the first
 * KHEAP_PAGES calls here are guaranteed to return ascending, contiguous
 * frames as long as that much contiguous free memory exists starting
 * from the lowest free frame - true for any normal E820 map (typically
 * one large usable block starting around 1MB). If this assumption
 * ever breaks (e.g. a future change allocates pages before heap init),
 * this would silently use a non-contiguous "heap" and corrupt memory -
 * worth remembering if this code is ever restructured.
 *
 * No coalescing of separated free blocks - only immediate-neighbor
 * merging when freeing, since the free list is singly-linked (no
 * "previous" pointer) and full coalescing would need one. This means
 * long-running alloc/free churn can fragment the heap over time. That
 * is an accepted limitation for now, not something worth a more
 * complex data structure for this project's scope.
 */

#include "kmalloc.h"
#include "pmm.h"

#define PAGE_SIZE 4096
#define KHEAP_PAGES 256   /* 1MB heap */
#define ALIGNMENT 8

struct block_header {
    unsigned int size;   /* size of the usable region after this header */
    int free;
    struct block_header *next;
};

static struct block_header *heap_head = 0;
static unsigned int heap_start = 0;
static unsigned int heap_size = 0;

static unsigned int align_up(unsigned int value, unsigned int align) {
    return (value + (align - 1)) & ~(align - 1);
}

void kheap_init(void) {
    unsigned int first_page = 0;

    for (int i = 0; i < KHEAP_PAGES; i++) {
        unsigned int page = pmm_alloc_page();
        if (page == 0) {
            /* Out of physical memory during boot-time heap setup - this
               is a fatal condition for a kernel that hasn't even
               finished initializing. There's no graceful recovery path
               yet (no swap, no reduced-heap fallback), so just stop
               rather than continuing with a broken/undersized heap that
               would fail confusingly later. */
            for (;;) {
                __asm__ volatile ("cli; hlt");
            }
        }
        if (i == 0) {
            first_page = page;
        }
        /* See the file header comment - we rely on these being
           contiguous rather than verifying it here, since verifying
           would require pmm to expose frame numbers directly. */
    }

    heap_start = first_page;
    heap_size = KHEAP_PAGES * PAGE_SIZE;

    heap_head = (struct block_header *)heap_start;
    heap_head->size = heap_size - sizeof(struct block_header);
    heap_head->free = 1;
    heap_head->next = 0;
}

void *kmalloc(unsigned int size) {
    if (size == 0) {
        return 0;
    }
    size = align_up(size, ALIGNMENT);

    struct block_header *block = heap_head;
    while (block != 0) {
        if (block->free && block->size >= size) {
            /* Split the block if there's enough leftover space to form
               a new usable block (header + at least ALIGNMENT bytes) -
               otherwise just hand over the whole block as-is to avoid
               creating unusably tiny fragments. */
            unsigned int remaining = block->size - size;
            if (remaining > sizeof(struct block_header) + ALIGNMENT) {
                struct block_header *new_block =
                    (struct block_header *)((unsigned char *)block + sizeof(struct block_header) + size);
                new_block->size = remaining - sizeof(struct block_header);
                new_block->free = 1;
                new_block->next = block->next;

                block->size = size;
                block->next = new_block;
            }

            block->free = 0;
            return (void *)((unsigned char *)block + sizeof(struct block_header));
        }
        block = block->next;
    }

    return 0; /* heap exhausted */
}

void kfree(void *ptr) {
    if (ptr == 0) {
        return;
    }

    struct block_header *block =
        (struct block_header *)((unsigned char *)ptr - sizeof(struct block_header));
    block->free = 1;

    /* Merge with the immediately following block if it's also free and
       physically adjacent (it always is adjacent in this design, since
       blocks are carved sequentially - "next" in the list is also
       "next" in memory, unlike a more general allocator). */
    if (block->next != 0 && block->next->free) {
        block->size += sizeof(struct block_header) + block->next->size;
        block->next = block->next->next;
    }
}

unsigned int kheap_total_bytes(void) {
    return heap_size;
}

unsigned int kheap_free_bytes(void) {
    unsigned int free_bytes = 0;
    struct block_header *block = heap_head;
    while (block != 0) {
        if (block->free) {
            free_bytes += block->size;
        }
        block = block->next;
    }
    return free_bytes;
}
