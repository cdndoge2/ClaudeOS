#ifndef CLAUDEOS_E820_H
#define CLAUDEOS_E820_H

/*
 * These addresses are where boot/stage2.S deposits the BIOS memory map
 * before switching to protected mode. They are NOT linked symbols -
 * stage2 and the kernel are separate binaries with no link-time
 * relationship (see docs/DEVLOG.md's note on the boot-drive hand-off
 * for why) - so these fixed physical addresses must be kept in sync
 * by hand between this file and boot/stage2.S's .set directives.
 * If you change one, change the other.
 */
#define E820_COUNT_ADDR    0x0510
#define E820_ENTRIES_ADDR  0xA000
#define E820_ENTRY_SIZE    24

#define E820_TYPE_USABLE   1

struct e820_entry {
    unsigned int base_low;
    unsigned int base_high;
    unsigned int length_low;
    unsigned int length_high;
    unsigned int type;
    unsigned int acpi_ext; /* not present on all BIOSes; ignored */
} __attribute__((packed));

#endif
