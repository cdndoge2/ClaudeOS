#ifndef CLAUDEOS_TICTACTOE_H
#define CLAUDEOS_TICTACTOE_H

/* Runs a full hotseat (two-player, same keyboard) game to completion,
   then waits for Enter before returning to the caller (the menu). */
void game_tictactoe(void);

#endif
