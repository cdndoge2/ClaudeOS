/*
 * Tic-Tac-Toe - hotseat two-player (same keyboard, alternating turns).
 * No AI opponent - this is the first game shipped mainly to prove the
 * menu -> game -> back-to-menu plumbing works end to end; single-
 * player-vs-computer is a natural follow-up once there's a reason to
 * write a minimax (or even just a dumb random-move) opponent.
 *
 * Board input uses the classic phone/numpad layout (1-9 mapped to
 * grid positions top-left to bottom-right) since it needs no cursor
 * movement - just typing a digit - which fits the same line-based
 * input model the rest of the shell/apps use (drivers/vga.c has no
 * arrow-key cursor addressing yet).
 */

#include "tictactoe.h"
#include "vga.h"
#include "keyboard.h"
#include "kstring.h"

static char board[9];

static void reset_board(void) {
    for (int i = 0; i < 9; i++) {
        board[i] = (char)('1' + i);
    }
}

static void print_cell(char c) {
    char buf[2] = { c, '\0' };
    term_print(buf);
}

static void print_board(void) {
    term_print(" ");
    print_cell(board[0]); term_print(" | ");
    print_cell(board[1]); term_print(" | ");
    print_cell(board[2]); term_print("\n---+---+---\n ");
    print_cell(board[3]); term_print(" | ");
    print_cell(board[4]); term_print(" | ");
    print_cell(board[5]); term_print("\n---+---+---\n ");
    print_cell(board[6]); term_print(" | ");
    print_cell(board[7]); term_print(" | ");
    print_cell(board[8]); term_print("\n");
}

static const int win_lines[8][3] = {
    {0, 1, 2}, {3, 4, 5}, {6, 7, 8}, /* rows */
    {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, /* columns */
    {0, 4, 8}, {2, 4, 6}             /* diagonals */
};

static char check_winner(void) {
    for (int i = 0; i < 8; i++) {
        int a = win_lines[i][0], b = win_lines[i][1], c = win_lines[i][2];
        if (board[a] == board[b] && board[b] == board[c] &&
            (board[a] == 'X' || board[a] == 'O')) {
            return board[a];
        }
    }
    return 0;
}

static int board_full(void) {
    for (int i = 0; i < 9; i++) {
        if (board[i] != 'X' && board[i] != 'O') {
            return 0;
        }
    }
    return 1;
}

static void wait_for_enter(void) {
    term_print("\nPress Enter to return to the menu...");
    char dummy[8];
    keyboard_read_line(dummy, sizeof(dummy));
}

void game_tictactoe(void) {
    reset_board();
    char current = 'X';

    term_clear();
    term_print("=== Tic-Tac-Toe ===\n");
    term_print("Two players, same keyboard. Enter 1-9 to place your mark.\n\n");

    for (;;) {
        print_board();
        term_print("\nPlayer ");
        print_cell(current);
        term_print(", enter cell (1-9): ");

        char line[8];
        keyboard_read_line(line, sizeof(line));

        if (kstrlen(line) != 1 || line[0] < '1' || line[0] > '9') {
            term_print("Invalid input - enter a single digit 1-9.\n\n");
            continue;
        }

        int index = line[0] - '1';
        if (board[index] == 'X' || board[index] == 'O') {
            term_print("That cell is already taken.\n\n");
            continue;
        }

        board[index] = current;

        char winner = check_winner();
        if (winner != 0) {
            term_clear();
            print_board();
            term_print("\nPlayer ");
            print_cell(winner);
            term_print(" wins!\n");
            wait_for_enter();
            return;
        }

        if (board_full()) {
            term_clear();
            print_board();
            term_print("\nIt's a draw!\n");
            wait_for_enter();
            return;
        }

        current = (current == 'X') ? 'O' : 'X';
        term_clear();
    }
}
