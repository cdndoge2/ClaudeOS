/*
 * ClaudeOS kernel - kmain
 *
 * Milestone 2 scope: interrupts. Install the IDT, register CPU
 * exception handlers (so crashes are diagnosable instead of silent
 * triple-faults), remap the PIC so hardware IRQs don't collide with
 * CPU exception vectors, and start the PIT as a system timer.
 */

#include "vga.h"
#include "idt.h"
#include "isr.h"
#include "irq.h"
#include "pic.h"
#include "pit.h"

void kmain(void) {
    vga_clear();
    vga_print_at("ClaudeOS - Milestone 2: interrupts", 0, 0);

    idt_install();
    isr_install_all();
    pic_remap();
    irq_install_all();

    vga_print_at("IDT installed, PIC remapped, IRQs registered", 1, 0);

    /* Enable interrupts only now that the IDT/PIC/IRQ handlers are all
       in place - enabling earlier risks an IRQ firing into an empty
       or half-configured IDT. */
    __asm__ volatile ("sti");

    pit_init(100); /* 100 Hz system timer tick */

    vga_print_at("Timer started at 100Hz. Tick count below:", 3, 0);

    for (;;) {
        char buf[16];
        unsigned int ticks = pit_get_ticks();
        int pos = 15;
        buf[pos] = '\0';
        if (ticks == 0) {
            buf[--pos] = '0';
        } else {
            while (ticks > 0 && pos > 0) {
                buf[--pos] = (char)('0' + (ticks % 10));
                ticks /= 10;
            }
        }
        vga_print_at("                    ", 4, 0); /* clear previous number */
        vga_print_at(&buf[pos], 4, 0);

        __asm__ volatile ("hlt");
    }
}
