#ifndef CLAUDEOS_VGA_H
#define CLAUDEOS_VGA_H

void vga_clear(void);
void vga_print_at(const char *str, int row, int col);

/* Clears the screen with an alarming color scheme (white on red) for
   exception/panic output, distinct from normal kernel output. */
void vga_panic_screen(void);

/* Prints "label: 0xXXXXXXXX" at the given row/col - used by the
   exception handler to dump register/vector values. */
void vga_print_kv(const char *label, unsigned int value, int row, int col);

#endif
