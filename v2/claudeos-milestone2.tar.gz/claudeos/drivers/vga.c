#include "vga.h"

#define VGA_MEMORY   ((volatile unsigned short *)0xB8000)
#define VGA_WIDTH    80
#define VGA_HEIGHT   25

#define COLOR_NORMAL 0x0F  /* white on black */
#define COLOR_PANIC  0x4F  /* white on red */

static unsigned char current_color = COLOR_NORMAL;

void vga_clear(void) {
    for (int i = 0; i < VGA_WIDTH * VGA_HEIGHT; i++) {
        VGA_MEMORY[i] = (current_color << 8) | ' ';
    }
}

void vga_print_at(const char *str, int row, int col) {
    int offset = row * VGA_WIDTH + col;
    for (int i = 0; str[i] != '\0'; i++) {
        VGA_MEMORY[offset + i] = (current_color << 8) | (unsigned char)str[i];
    }
}

void vga_panic_screen(void) {
    current_color = COLOR_PANIC;
    vga_clear();
}

/* Minimal hex formatter - no snprintf available (freestanding, no libc). */
static void format_hex32(unsigned int value, char *out) {
    const char *digits = "0123456789ABCDEF";
    out[0] = '0';
    out[1] = 'x';
    for (int i = 0; i < 8; i++) {
        unsigned int shift = (7 - i) * 4;
        out[2 + i] = digits[(value >> shift) & 0xF];
    }
    out[10] = '\0';
}

void vga_print_kv(const char *label, unsigned int value, int row, int col) {
    vga_print_at(label, row, col);

    int label_len = 0;
    while (label[label_len] != '\0') label_len++;

    vga_print_at(": ", row, col + label_len);

    char hexbuf[11];
    format_hex32(value, hexbuf);
    vga_print_at(hexbuf, row, col + label_len + 2);
}
