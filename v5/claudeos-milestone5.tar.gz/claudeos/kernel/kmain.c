/*
 * ClaudeOS kernel - kmain
 *
 * Milestone 5 scope: persistent storage (ATA PIO + a simple flat
 * filesystem) plus the first real applications (file management,
 * notepad, calculator, sysinfo) built on top of it.
 */

#include "vga.h"
#include "idt.h"
#include "isr.h"
#include "irq.h"
#include "pic.h"
#include "pit.h"
#include "keyboard.h"
#include "shell.h"
#include "pmm.h"
#include "kmalloc.h"
#include "fs.h"

void kmain(void) {
    vga_clear();
    vga_print_at("ClaudeOS - Milestone 5: storage + apps", 0, 0);
    vga_print_at("Initializing...", 1, 0);

    idt_install();
    isr_install_all();
    pic_remap();
    irq_install_all();
    keyboard_init();

    __asm__ volatile ("sti");

    pit_init(100);

    pmm_init();
    kheap_init();
    fs_init();

    term_clear();
    shell_run();

    /* shell_run() has an infinite command loop and should never
       return, but if it somehow does, don't fall off into garbage -
       halt cleanly. */
    for (;;) {
        __asm__ volatile ("cli; hlt");
    }
}
