/*
 * ClaudeOS shell.
 *
 * A minimal command loop: print a prompt, read a line, dispatch to a
 * built-in command. No filesystem or app-launching yet, so commands
 * are hardcoded here - that will change once storage (Milestone
 * "Persistent Storage") and app-launching land, at which point this
 * dispatch table gets replaced with something that can also invoke
 * loaded programs.
 */

#include "shell.h"
#include "vga.h"
#include "keyboard.h"
#include "kstring.h"
#include "pit.h"
#include "ports.h"
#include "pmm.h"
#include "kmalloc.h"
#include "fs.h"

#define CMD_BUFFER_SIZE 128

static void print_uint(unsigned int value) {
    char buf[16];
    int pos = 15;
    buf[pos] = '\0';
    if (value == 0) {
        buf[--pos] = '0';
    } else {
        while (value > 0 && pos > 0) {
            buf[--pos] = (char)('0' + (value % 10));
            value /= 10;
        }
    }
    term_print(&buf[pos]);
}

static void print_int(int value) {
    if (value < 0) {
        term_print("-");
        print_uint((unsigned int)(-value));
    } else {
        print_uint((unsigned int)value);
    }
}

static void cmd_help(void) {
    term_print("Available commands:\n");
    term_print("  help          - show this list\n");
    term_print("  clear         - clear the screen\n");
    term_print("  echo X        - print X back\n");
    term_print("  uptime        - show system timer ticks since boot\n");
    term_print("  meminfo       - show physical memory and heap usage\n");
    term_print("  sysinfo       - show full system information\n");
    term_print("  version       - show ClaudeOS version info\n");
    term_print("  ls            - list saved files\n");
    term_print("  write F TEXT  - save TEXT to file F (one line)\n");
    term_print("  cat F         - print file F's contents\n");
    term_print("  rm F          - delete file F\n");
    term_print("  notepad F     - open file F in the line editor\n");
    term_print("  calc A OP B   - integer calculator (+ - * /)\n");
    term_print("  reboot        - restart the machine\n");
}

static void cmd_echo(const char *args) {
    term_print(args);
    term_print("\n");
}

static void cmd_uptime(void) {
    term_print("Ticks since boot: ");
    print_uint(pit_get_ticks());
    term_print(" (100 ticks = 1 second)\n");
}

static void cmd_version(void) {
    term_print("ClaudeOS - Milestone 5 (persistent storage + apps)\n");
}

static void cmd_meminfo(void) {
    unsigned int total_frames = pmm_total_frame_count();
    unsigned int free_frames = pmm_free_frame_count();
    unsigned int used_frames = total_frames - free_frames;

    term_print("Physical memory (4KB frames):\n");
    term_print("  Total addressable: "); print_uint(total_frames); term_print(" frames (");
    print_uint(total_frames * 4); term_print(" KB)\n");
    term_print("  Used:              "); print_uint(used_frames); term_print(" frames (");
    print_uint(used_frames * 4); term_print(" KB)\n");
    term_print("  Free:              "); print_uint(free_frames); term_print(" frames (");
    print_uint(free_frames * 4); term_print(" KB)\n");

    term_print("Kernel heap:\n");
    term_print("  Total: "); print_uint(kheap_total_bytes() / 1024); term_print(" KB\n");
    term_print("  Free:  "); print_uint(kheap_free_bytes() / 1024); term_print(" KB\n");
}

static void cmd_reboot(void) {
    term_print("Rebooting...\n");
    /* Classic PS/2 controller reboot trick: pulse the CPU reset line
       via the keyboard controller's command port. Wait for the input
       buffer to be clear first (bit 1 of the status port) so we don't
       send this while the controller is busy with something else. */
    unsigned char status;
    do {
        status = inb(0x64);
    } while (status & 0x02);
    outb(0x64, 0xFE);

    /* If the reset didn't take (some emulators/hardware are picky),
       don't silently hang - say so and halt cleanly. */
    term_print("Reboot signal sent but system did not reset.\n");
    for (;;) {
        __asm__ volatile ("cli; hlt");
    }
}

/* ---------------- File management (built on kernel/fs.c) ---------------- */

static void cmd_ls(void) {
    char name[FS_NAME_LEN + 1];
    unsigned int size;
    int any = 0;

    term_print("Files:\n");
    for (int i = 0; i < FS_MAX_FILES; i++) {
        if (fs_get_slot_info(i, name, &size)) {
            any = 1;
            term_print("  ");
            term_print(name);
            term_print(" (");
            print_uint(size);
            term_print(" bytes)\n");
        }
    }
    if (!any) {
        term_print("  (no files)\n");
    }
}

/* "write <name> <text>" - a quick one-line save, distinct from the
   full-screen notepad below. Splits at the first space after the
   filename; everything after that is the file's entire content. */
static void cmd_write(const char *args) {
    int i = 0;
    while (args[i] != '\0' && args[i] != ' ') i++;

    if (args[i] == '\0') {
        term_print("Usage: write <filename> <text>\n");
        return;
    }

    char name[FS_NAME_LEN + 1];
    int namelen = i;
    if (namelen > FS_NAME_LEN) {
        namelen = FS_NAME_LEN;
    }
    kmemcpy(name, args, (unsigned int)namelen);
    name[namelen] = '\0';

    const char *text = &args[i + 1];
    if (fs_write(name, text, (unsigned int)kstrlen(text)) == 0) {
        term_print("Saved.\n");
    } else {
        term_print("Write failed (filename too long or file too large).\n");
    }
}

static void cmd_cat(const char *name) {
    if (kstrlen(name) == 0) {
        term_print("Usage: cat <filename>\n");
        return;
    }

    char *buf = (char *)kmalloc(FS_MAX_FILE_SIZE);
    if (buf == 0) {
        term_print("Out of memory.\n");
        return;
    }

    int result = fs_read(name, buf, FS_MAX_FILE_SIZE);
    if (result < 0) {
        term_print("File not found: ");
        term_print(name);
        term_print("\n");
    } else {
        term_print(buf);
        if (result == 0 || buf[result - 1] != '\n') {
            term_print("\n");
        }
    }
    kfree(buf);
}

static void cmd_rm(const char *name) {
    if (kstrlen(name) == 0) {
        term_print("Usage: rm <filename>\n");
        return;
    }
    if (fs_delete(name) == 0) {
        term_print("Deleted.\n");
    } else {
        term_print("File not found: ");
        term_print(name);
        term_print("\n");
    }
}

/* ---------------- Notepad app ----------------
 * A minimal line-based text editor: shows the file's current content
 * (if any), then reads lines and appends them to an in-memory buffer
 * until the user types ":wq" (save and quit) or ":q" (discard and
 * quit) as a standalone line. No cursor movement, no editing existing
 * lines - appending only. A real screen-editing notepad (moving the
 * cursor within existing text) would need much more of a terminal
 * abstraction than drivers/vga.c currently provides; this line-editor
 * style (same spirit as `ed` or early micro editors) is a deliberate
 * scope choice for what "notepad" means in a project this size. */
static void cmd_notepad(const char *filename) {
    if (kstrlen(filename) == 0) {
        term_print("Usage: notepad <filename>\n");
        return;
    }

    char *content = (char *)kmalloc(FS_MAX_FILE_SIZE);
    if (content == 0) {
        term_print("Out of memory.\n");
        return;
    }

    unsigned int len = 0;
    int existing = fs_read(filename, content, FS_MAX_FILE_SIZE);
    if (existing > 0) {
        len = (unsigned int)existing;
        term_print(content);
        if (content[len - 1] != '\n') {
            term_print("\n");
        }
    }

    term_print("--- Notepad: ");
    term_print(filename);
    term_print(" (:wq to save+quit, :q to discard+quit) ---\n");

    for (;;) {
        char line[CMD_BUFFER_SIZE];
        keyboard_read_line(line, CMD_BUFFER_SIZE);

        if (kstrcmp(line, ":wq") == 0) {
            if (fs_write(filename, content, len) == 0) {
                term_print("Saved.\n");
            } else {
                term_print("Save failed (filename too long?).\n");
            }
            break;
        } else if (kstrcmp(line, ":q") == 0) {
            term_print("Discarded changes.\n");
            break;
        }

        unsigned int line_len = (unsigned int)kstrlen(line);
        if (len + line_len + 1 >= FS_MAX_FILE_SIZE) {
            term_print("File full (8KB max) - line not added.\n");
            continue;
        }
        kmemcpy(content + len, line, line_len);
        len += line_len;
        content[len++] = '\n';
    }

    kfree(content);
}

/* ---------------- Calculator app ---------------- */

static int parse_int(const char *s, int *out) {
    int i = 0;
    int negative = 0;
    unsigned int value = 0;

    if (s[0] == '-') {
        negative = 1;
        i = 1;
    }
    if (s[i] == '\0') {
        return -1; /* no digits at all */
    }
    for (; s[i] != '\0'; i++) {
        if (s[i] < '0' || s[i] > '9') {
            return -1;
        }
        value = value * 10 + (unsigned int)(s[i] - '0');
    }

    *out = negative ? -(int)value : (int)value;
    return 0;
}

/* "calc <a> <op> <b>" - tokenizes three space-separated fields out of
   args by hand, since there's no strtok in this freestanding build. */
static void cmd_calc(const char *args) {
    int i = 0;
    while (args[i] == ' ') i++;
    int start1 = i;
    while (args[i] != '\0' && args[i] != ' ') i++;
    int len1 = i - start1;

    while (args[i] == ' ') i++;
    int op_start = i;
    while (args[i] != '\0' && args[i] != ' ') i++;
    int op_len = i - op_start;

    while (args[i] == ' ') i++;
    int start2 = i;
    while (args[i] != '\0' && args[i] != ' ') i++;
    int len2 = i - start2;

    if (len1 <= 0 || len1 >= 32 || op_len != 1 || len2 <= 0 || len2 >= 32) {
        term_print("Usage: calc <number> <+|-|*|/> <number>\n");
        return;
    }

    char num1[32], num2[32];
    kmemcpy(num1, args + start1, (unsigned int)len1); num1[len1] = '\0';
    kmemcpy(num2, args + start2, (unsigned int)len2); num2[len2] = '\0';
    char op = args[op_start];

    int a, b;
    if (parse_int(num1, &a) != 0 || parse_int(num2, &b) != 0) {
        term_print("Invalid number.\n");
        return;
    }

    int result;
    switch (op) {
        case '+': result = a + b; break;
        case '-': result = a - b; break;
        case '*': result = a * b; break;
        case '/':
            if (b == 0) {
                term_print("Division by zero.\n");
                return;
            }
            result = a / b;
            break;
        default:
            term_print("Unknown operator (use + - * /).\n");
            return;
    }

    print_int(result);
    term_print("\n");
}

/* ---------------- System info app ---------------- */

static void cmd_sysinfo(void) {
    term_print("=== ClaudeOS System Information ===\n");
    cmd_version();
    cmd_uptime();
    cmd_meminfo();
    term_print("Filesystem: ClaudeFS - ");
    print_uint(FS_MAX_FILES);
    term_print(" file slots, ");
    print_uint(FS_MAX_FILE_SIZE / 1024);
    term_print("KB max per file\n");
}

static void dispatch(char *line) {
    /* Trim nothing fancy - just find the first space to split
       command from arguments, if any. */
    int i = 0;
    while (line[i] != '\0' && line[i] != ' ') i++;

    char saved = line[i];
    line[i] = '\0';
    const char *cmd = line;
    const char *args = (saved == ' ') ? &line[i + 1] : "";

    if (kstrlen(cmd) == 0) {
        return; /* empty line - just show the prompt again */
    } else if (kstrcmp(cmd, "help") == 0) {
        cmd_help();
    } else if (kstrcmp(cmd, "clear") == 0) {
        term_clear();
    } else if (kstrcmp(cmd, "echo") == 0) {
        cmd_echo(args);
    } else if (kstrcmp(cmd, "uptime") == 0) {
        cmd_uptime();
    } else if (kstrcmp(cmd, "meminfo") == 0) {
        cmd_meminfo();
    } else if (kstrcmp(cmd, "sysinfo") == 0) {
        cmd_sysinfo();
    } else if (kstrcmp(cmd, "version") == 0) {
        cmd_version();
    } else if (kstrcmp(cmd, "ls") == 0) {
        cmd_ls();
    } else if (kstrcmp(cmd, "write") == 0) {
        cmd_write(args);
    } else if (kstrcmp(cmd, "cat") == 0) {
        cmd_cat(args);
    } else if (kstrcmp(cmd, "rm") == 0) {
        cmd_rm(args);
    } else if (kstrcmp(cmd, "notepad") == 0) {
        cmd_notepad(args);
    } else if (kstrcmp(cmd, "calc") == 0) {
        cmd_calc(args);
    } else if (kstrcmp(cmd, "reboot") == 0) {
        cmd_reboot();
    } else {
        term_print("Unknown command: ");
        term_print(cmd);
        term_print(" (type 'help' for a list)\n");
    }
}

void shell_run(void) {
    char line[CMD_BUFFER_SIZE];

    term_print("\nClaudeOS shell - type 'help' for available commands\n\n");

    for (;;) {
        term_print("> ");
        keyboard_read_line(line, CMD_BUFFER_SIZE);
        dispatch(line);
    }
}
