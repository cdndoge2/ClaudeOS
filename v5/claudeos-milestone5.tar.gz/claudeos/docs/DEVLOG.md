# ClaudeOS Development Log

## Milestone 1: Boot chain (stage1 -> stage2 -> protected mode -> C kernel)

**Date:** 2026-08-22

### Environment constraints discovered

Before writing any code, I checked the actual dev sandbox tooling rather
than assuming a typical OS-dev setup:

- `nasm`: not installed, and the sandbox has no internet access, so
  `apt-get install nasm` fails (confirmed — 403s from the package mirror).
- `qemu-system-x86_64` / `qemu-system-i386`: not installed, same problem.
  No QEMU binary exists anywhere on the filesystem.
- `gcc`, `binutils` (`as`, `ld`, `objcopy`), `make`: all present.

**Consequence:** I cannot boot-test this project myself in this
environment. This is an important limitation to be upfront about per the
project's own ground rules ("do not pretend code works if it has not been
tested"). What I *can* do, and have done, is static verification:
- Confirm the boot sector is exactly 512 bytes ending in `0x55 0xAA`.
- Disassemble the built binaries and manually check the decoded
  instructions match the intended source logic.
- Confirm linker-placed symbol addresses match the addresses the
  bootloader jumps to.

This does not replace actually booting it. **The first real test needs to
happen in QEMU on the user's machine.** See README.md for exact commands.

### Assembler substitution: GAS instead of NASM

Since NASM isn't available and can't be installed, I used GNU `as` with
AT&T syntax and the `.code16gcc` pseudo-directive for real-mode 16-bit
code generation. This is a legitimate, precedented approach (used by
various GRUB-adjacent and older Linux boot code), but it's worth flagging
explicitly since most hobby-OS tutorials and expectations assume NASM.
If this becomes a blocker for the user's workflow, the boot code would
need a syntax rewrite — not done preemptively since it works as-is.

### Architecture decisions

**Two-stage boot.** A 512-byte MBR sector can't fit disk-read logic +
A20 enable + GDT setup + protected-mode switch + kernel loading. Stage 1
only loads Stage 2 (16 sectors / 8KB budget) via BIOS `INT 13h, AH=42h`
(LBA-addressed extended read — chosen over the older CHS-addressed
`AH=02h` because it's simpler to reason about and universally supported
in emulators and modern BIOS/UEFI-CSM).

**Boot-drive hand-off via fixed memory address, not linked symbols.**
Stage 1 and Stage 2 are assembled and `objcopy`'d to raw binaries
*separately* — they are never linked together into one ELF, since each
needs to be placed at a different fixed load address as raw machine code
for the BIOS to jump into directly. That means an `.extern` symbol
reference across the two files silently doesn't work (caught this while
writing stage2.S — first draft referenced `boot_drive` as an extern,
which would not have linked correctly). Fixed instead: both stages
hardcode address `0x0500` (a conventionally free low-memory scratch
location, just above the BIOS data area) as a hand-off slot for the
BIOS-provided boot drive number.

**Kernel loaded at 0x10000 (64KB mark), not 0x100000 (1MB mark).**
Real-mode BIOS disk reads can only target memory reachable in real mode
(effectively at/below ~1MB, and only cleanly below it without A20
trickery). Loading the kernel above 1MB would require either (a) a
real-mode-to-protected-mode copy step, or (b) "unreal mode" tricks to do
big real-mode memory moves. For a sub-512KB hobby kernel, staying below
1MB avoids all of that complexity for no real cost — there's ~576KB of
conventional memory between 0x10000 and the EBDA, comfortably more than
our entire size budget.

**A20 line: fast A20 method via port 0x92 only.** This is the simplest
of the ~3 common A20-enable methods and works on QEMU/Bochs and most real
hardware. The classic keyboard-controller method is more universally
compatible on *old* real hardware but adds real complexity for a case we
don't expect to hit. Flagged as a place to revisit if real-hardware
testing ever shows A20 isn't actually enabled.

**Flat GDT, ring 0 only, no paging yet.** Simplest possible protected-mode
memory model: two overlapping 4GB segments (code, data), no privilege
separation. Appropriate for where the project is right now; paging and
any privilege separation are explicitly deferred, not forgotten.

### Current size budget tracking

| Component  | Actual size | Budget    |
|------------|-------------|-----------|
| boot.bin   | 512 bytes   | 512 (fixed) |
| stage2.bin | 320 bytes   | 8192 (16 sectors) |
| kernel.bin | 320 bytes   | 51200 (100 sectors) |
| **Total image** | **59904 bytes (~58.5KB)** | **524288 (512KB)** |

Enormous headroom right now because the kernel only clears the screen and
prints two strings. This will fill up fast once memory management,
interrupts, the shell, filesystem, and apps land — tracked here at every
milestone from now on.

### What's verified vs. not

**Verified (statically):**
- boot.bin is exactly 512 bytes with correct `0x55AA` signature.
- Disassembly of boot.bin and stage2.bin matches the intended source
  logic instruction-by-instruction.
- kernel.elf places `_start` at 0x10000 and `kmain` immediately after,
  matching where stage2 jumps.
- Build produces a complete, correctly-laid-out disk image with no
  linker/assembler errors.

**Not yet verified (needs QEMU):**
- Does the BIOS actually load and jump to stage1 correctly?
- Does the extended INT13 disk read actually work in the emulator/on
  real BIOS?
- Does A20 actually get enabled?
- Does the protected-mode transition actually succeed (no triple fault)?
- Does the kernel actually run and produce visible VGA output?

**Next steps (pending your QEMU test results):**
1. Confirm Milestone 1 actually boots.
2. If it doesn't: debug using QEMU's `-d int,cpu_reset` logging and
   whatever output you can share.
3. If it does: move to Milestone 2 — interrupt handling (IDT, PIC
   remapping) and the system timer (PIT), since the shell and keyboard
   input both depend on interrupts working first.

---

## Bug #1: stage2 linked at wrong address (found via first real QEMU test)

**Symptom (reported by user, QEMU/SeaBIOS):** stage1's own messages
("loading stage2...", "stage2 loaded, jumping...") printed correctly, but
after the jump into stage2, the screen showed garbage characters (box-
drawing/symbol glyphs) instead of "ClaudeOS: stage2 running", then
stopped -- no hang message, no further progress.

**Root cause:** in the Makefile, stage2 was linked with
`ld -Ttext 0x0`, telling the linker to bake in absolute addresses as if
the code would be loaded starting at address 0. But stage1 actually
loads stage2 at linear address `0x7E00` (segment 0x0000, offset 0x7E00,
per the DAP in boot.S). So every absolute reference in stage2 -- e.g.
`mov $msg_stage2, %si` -- was compiled to point at address-relative-to-0
instead of address-relative-to-0x7E00. At runtime, `SI` ended up
pointing roughly 0x7E00 bytes before where the actual string data
lived, i.e. into unrelated low memory (IVT/BDA region), and
`print_string` dutifully printed whatever garbage bytes were sitting
there via `int 10h` -- which explains the box-drawing/symbol characters
exactly: not a crash, not a hang, just correct code faithfully printing
the wrong memory.

**Why this didn't get caught by static verification before shipping:**
I disassembled stage2.bin and manually read the instruction *shapes*
(mov, call, jc, etc.) and confirmed they matched the source's control
flow -- but I didn't cross-check the *absolute addresses* embedded in
those instructions against where the binary is actually loaded at
runtime. That's the gap: verifying "this looks like the right code" is
not the same as verifying "this code will do the right thing at its
actual load address." boot.bin happened to be linked correctly
(`-Ttext 0x7C00`, matching its real 0x7C00 load address), so it worked;
I didn't apply the same scrutiny to stage2's link address and used a
placeholder `0x0` without checking it against `STAGE2_LOAD_OFF`.

**Fix:** changed stage2's link address to `-Ttext 0x7E00`, matching
`STAGE2_LOAD_OFF` in both boot.S and stage2.S. Re-disassembled and
confirmed addresses embedded in the code now fall correctly within
stage2's actual 0x7E00+ load range (e.g. `mov $0x7e7f, %si` instead of
`mov $0x7f, %si`).

**Lesson applied going forward:** for every future raw-binary-linked
component, explicitly verify the link/load address match by
disassembling with `--adjust-vma` set to the real load address and
confirming embedded absolute addresses land inside that component's own
range -- not just that the instructions look structurally right.

**Status:** Fixed and confirmed working in QEMU (SeaBIOS) by the user —
full boot chain verified end to end: BIOS loads stage1, stage1 loads and
jumps to stage2, stage2 enables A20 and enters protected mode, kernel
runs and writes correctly to the VGA buffer. Milestone 1 complete.

---

## Milestone 2: Interrupts (IDT, exceptions, PIC remap, IRQs, PIT timer)

**Date:** 2026-08-22

### Scope

- IDT with all 256 vectors initialized (kernel/idt.c, kernel/idt_load.S).
- CPU exception handlers for vectors 0-31 (kernel/isr_stubs.S,
  kernel/isr.c) - currently a "panic" handler that prints the exception
  name, vector, error code, and faulting EIP/CS/EFLAGS to the screen
  and halts, rather than silently triple-faulting/rebooting. This is
  deliberately not fancy - there's no recovery mechanism yet since
  there's no process model to recover *to* - but it makes every future
  bug in this project vastly easier to diagnose than a blank reboot.
- 8259 PIC remap (kernel/pic.c) - hardware IRQs moved from their BIOS
  default vectors (which collide with CPU exceptions) to 32-47.
- Generic IRQ stub/dispatch layer (kernel/irq_stubs.S, kernel/irq.c)
  with a handler-registration table, so drivers (PIT now, keyboard
  next) don't need to touch the IDT or PIC directly.
- PIT (kernel/pit.c) programmed as a 100Hz system timer on IRQ0,
  counting ticks - the foundation for future delays/timeouts/scheduling.
- Extracted VGA text-mode output into a real driver (drivers/vga.c/h)
  instead of static functions living in kmain.c, since isr.c also needs
  it for panic output.

### Bug caught before shipping: object filename collision

`isr.S` and `isr.c` both would have compiled to `build/isr.o` (same for
`irq.S`/`irq.c`), silently overwriting one or the other depending on
build order. The linker then reported "multiple definition" errors for
every ISR/IRQ stub *and*, confusingly, "undefined reference" errors for
the C-side handler functions in the same build - because the surviving
isr.o was the C object, so the assembly stub symbols were missing
entirely from the link. Fixed by renaming the assembly files to
`isr_stubs.S` / `irq_stubs.S`. Caught immediately from the build output,
not from runtime behavior - a good reminder to actually read `make`'s
full output rather than just checking the exit code.

### Bug caught before shipping: .bss not zeroed

`objcopy -O binary` drops `.bss` from the output entirely - it's
reserved address space, not file content. That means nothing guarantees
zero-initialized statics (e.g. `irq_handlers[16]` in irq.c) actually
start at zero; they'd contain whatever was physically in that RAM
before our code ran. This happens to work by accident in QEMU (RAM
starts zeroed, and our sector padding also happens to zero-pad most of
the range in this case), but relying on that would be fragile and wrong
on real hardware or once more code loads before the kernel. Fixed by
adding `__bss_start`/`__bss_end` symbols to the linker script and an
explicit zeroing loop (`rep stosb`) at the very start of entry.S, before
the stack is even set up.

### Architecture decisions

**Panic instead of resume for exceptions.** Some hobby OSes try to
gracefully resume from certain exceptions. We don't, on purpose - with
no process/memory isolation model yet, "resuming" from e.g. a general
protection fault has no well-defined meaning. A clear diagnostic panic
screen is more honest and more useful right now than pretending to
recover.

**IRQs are edge cases of the same stub pattern as exceptions**, not a
totally separate mechanism - both push a vector number onto a uniform
stack frame and jump to a common C dispatcher. This is why irq.c's
`struct irq_frame` is structurally identical to isr.c's `struct
isr_frame`; kept as separate types rather than sharing one, since
exceptions and hardware interrupts are conceptually distinct even
though the plumbing happens to match.

**Driver registration table for IRQs, not hardcoded per-IRQ logic in
the dispatcher.** `irq_register_handler(0, pit_irq_handler)` keeps
pit.c from needing to know anything about IDT gates, PIC EOI, or stub
mechanics - it just says "call me on IRQ0." This is the pattern the
keyboard driver will follow next.

### Size budget tracking

| Component  | Actual size | Budget    |
|------------|-------------|-----------|
| boot.bin   | 512 bytes   | 512 (fixed) |
| stage2.bin | 320 bytes   | 8192 (16 sectors) |
| kernel.bin | 3425 bytes  | 51200 (100 sectors) |
| **Total image** | **59904 bytes (~58.5KB)** | **524288 (512KB)** |

Kernel grew from 320 -> 3425 bytes (interrupts/PIC/PIT/panic screen
infrastructure). Still enormous headroom.

### What's verified vs. not

**Verified (statically):** clean build with no unexpected warnings;
`_start`/`kmain`/`isr_common_handler`/`irq_common_handler` symbols land
at sensible, non-overlapping addresses; `__bss_start`/`__bss_end` bracket
a sane region including the kernel stack; disassembly of `idt_load` and
the ISR stub macro expansion matches intended logic.

**Not yet verified (needs QEMU):** does `lidt` actually succeed; do
exceptions actually route through our handlers (worth deliberately
triggering one, e.g. divide-by-zero, to see the panic screen); does the
PIC remap avoid breaking anything; does the PIT tick counter actually
increment on screen once per ~10ms.

**Status:** Confirmed working in QEMU by the user - IDT, PIC remap,
IRQ dispatch, and PIT timer all functioning correctly; tick counter
visibly incrementing on screen. Milestone 2 complete.

---

## Milestone 3: Keyboard input + basic shell

**Date:** 2026-08-23

### Scope

- PS/2 keyboard driver (drivers/keyboard.c/h) - reads scancode set 1
  from port 0x60 on IRQ1, translates to ASCII via a lookup table,
  handles Shift as a modifier, provides a blocking `keyboard_getchar()`
  and a `keyboard_read_line()` with backspace support. Extended
  (0xE0-prefixed) keys like arrow keys are consumed but not acted on
  yet - not needed until something wants line editing or navigation.
- Upgraded the VGA driver from fixed row/col printing to a real
  scrolling terminal (`term_clear`/`term_putc`/`term_print` in
  drivers/vga.c) with a tracked cursor, newline/backspace handling,
  scroll-up when text runs off the bottom, and hardware cursor sync via
  the VGA CRTC ports (0x3D4/0x3D5) so a blinking cursor is visible.
  vga_print_at (fixed-position) is kept as-is for boot-time status
  messages and the panic screen, which don't want scrolling behavior.
- Minimal string helpers (kernel/kstring.c/h: kstrlen, kstrcmp,
  kstrncmp) - freestanding builds have no libc, and the shell's command
  dispatch needs basic string comparison.
- Shell (kernel/shell.c/h): prompt/read/dispatch loop with built-in
  commands `help`, `clear`, `echo`, `uptime` (reads the PIT tick
  counter from Milestone 2), `version`, and `reboot`.

### Note on repo state at the start of this milestone

Keyboard.c/h, kstring.c/h, and shell.c/h were already present on disk
at the start of this work session, fully written, but kmain.c was
missing and the Makefile hadn't been updated to compile the new files.
Rather than assume this prior work was correct, I read every line of
each file against my own understanding of PS/2 scancode set 1, the
shell's expected behavior, and the existing codebase's conventions
before using any of it - confirming the scancode table entries against
the standard scancode-to-key mapping, checking the circular keyboard
buffer logic, and checking shell.c's command dispatch and reboot
sequence. All of it checked out and is used as-is. Wrote kmain.c to
wire it together and updated the Makefile to compile the missing
sources.

### Architecture decisions

**Blocking keyboard read via `hlt`, no polling.** `keyboard_getchar()`
spins in a `hlt` loop until the circular buffer has data. Since `hlt`
halts the CPU until the next interrupt (and the keyboard IRQ handler is
what fills the buffer), this is not a busy-wait burning CPU cycles -
the CPU is genuinely idle between keystrokes. This is the same pattern
the Milestone 2 kmain loop used while waiting for timer ticks.

**Two separate VGA output paths, not one.** `vga_print_at` (fixed
position, no cursor state) is kept for boot-time status lines and the
panic screen, which want to place text at known coordinates and are
one-shot. `term_*` (cursor-tracked, scrolling) is what the shell uses,
since a real console needs to remember where it left off and handle
overflow. Merging these into one API would have made the simpler
one-shot use case (panic screen) carry scrolling-cursor complexity it
doesn't need.

**Reboot via 8042 keyboard-controller reset pulse.** This is the
standard, widely-compatible software reboot trick for x86 (works on
real hardware going back decades and on QEMU/Bochs) - pulse the CPU
reset line through the keyboard controller's command port after
confirming its input buffer is clear. No ACPI/APM shutdown command
implemented yet - real ACPI shutdown requires parsing ACPI tables
(FADT/DSDT) to find the correct PM1 control port and values, which is
a meaningfully bigger feature deferred to a later milestone rather than
implemented as a fragile guess now.

### Size budget tracking

| Component  | Actual size | Budget    |
|------------|-------------|-----------|
| boot.bin   | 512 bytes   | 512 (fixed) |
| stage2.bin | 320 bytes   | 8192 (16 sectors) |
| kernel.bin | 6401 bytes  | 51200 (100 sectors) |
| **Total image** | **59904 bytes (~58.5KB)** | **524288 (512KB)** |

### What's verified vs. not

**Verified (statically):** clean build, zero unexpected warnings, zero
undefined symbols in the final ELF (`nm -u` empty); disassembly of
`shell_run` confirms it calls `term_print` then `keyboard_read_line`
with the arguments the source specifies; disassembly of the PIC/port-IO
code shows sane `in`/`out` instruction sequences: manual line-by-line
review of the keyboard scancode table against the standard PS/2 set-1
layout.

**Not yet verified (needs QEMU):** does the keyboard actually produce
correct characters on screen (including Shift); does Backspace behave
correctly at the start of a line (should not erase past where the
prompt starts, though the current implementation doesn't specifically
protect against backspacing into "> " - worth checking); do `help`,
`echo`, `uptime`, `version` behave as expected; does `reboot` actually
reboot the emulator or the "did not reset" fallback fire instead; does
the terminal scroll correctly once enough lines have been printed.

**Known gap to watch for:** `keyboard_read_line` has no protection
against Backspace deleting past the start of the current input line
into the "> " prompt itself, since it only tracks `len` (characters
typed this line) and stops at `len == 0` - so this should actually be
safe (backspace is a no-op once len reaches 0), but it's worth
confirming visually since terminal cursor/erase bugs are easy to miss
by inspection alone.

**Status:** Confirmed working in QEMU by the user - keyboard input,
Shift-symbol handling, backspace, and all shell commands (help, echo,
uptime, version) all function correctly. Milestone 3 complete.

**Next steps:** confirm the shell is interactive and usable. Then
Milestone 4 (per the original roadmap): memory management, followed by
persistent storage - the shell's command surface won't get much more
interesting until there's a filesystem for it to act on.

---

## Milestone 4: Memory management (E820 detection, physical frame allocator, kernel heap)

**Date:** 2026-08-23

### Scope

- BIOS memory detection via `INT 15h, EAX=0xE820` ("SMAP"), added to
  boot/stage2.S between A20 enable and the protected-mode switch -
  this has to happen in real mode, since it's a BIOS call the
  protected-mode kernel can't make itself. Results (entry count +
  entries) are deposited at fixed physical addresses (0x0510 for the
  count, 0xA000 for the entries) using the same fixed-address hand-off
  pattern established for the boot drive number in Milestone 1, since
  stage2 and the kernel are separate, unlinked binaries.
- Physical memory manager (kernel/pmm.c/h): a bitmap-based 4KB page
  frame allocator built from the E820 map. Caps supported memory at
  256MB (a fixed-size static bitmap, avoiding a dynamic-sizing
  chicken-and-egg problem before any allocator exists) and
  unconditionally reserves the first 1MB regardless of what E820
  claims about it, since that's where real-mode structures, our own
  bootloader, and the kernel itself all live.
- Kernel heap allocator (kernel/kmalloc.c/h): a first-fit singly-linked
  free list over a 1MB region carved from 256 pages requested from the
  PMM at boot.
- New shell command `meminfo` showing physical frame usage and heap
  usage.

### A GCC warning worth actually chasing down

Compiling pmm.c produced:
```
warning: array subscript 0 is outside array bounds of 'volatile unsigned int[0]'
note: source object is likely at address zero
```
on the line reading the E820 entry count from a fixed address
(`*(volatile unsigned int *)E820_COUNT_ADDR`, i.e. address 0x0510).
This is exactly the kind of warning that could mean a real problem (a
freestanding-code pattern GCC's optimizer mishandled) or could be a
false positive from GCC's array-bounds static analysis getting
confused by small-integer-to-pointer casts, which is a known category
of false positive in bare-metal/embedded C. Rather than assume either
way, I disassembled the actual linked output and confirmed the
generated code correctly loads from `ds:0x510` and correctly computes
the bitmap array's real linked address (`0x167e0`) for the
initialization loop - the load isn't optimized away or miscomputed.
Also worth noting: I initially misread this same disassembly output
when checking the *unlinked* object file first, where addresses are
placeholder relocation values (e.g. the bitmap "address" appeared to
be near zero) - re-checking the same code in the final linked ELF
resolved that confusion. Recorded here as a reminder: always verify
suspicious codegen against the linked binary, not an intermediate
object file, since relocations aren't applied yet in the latter.

### Architecture decisions

**Real-mode memory detection can't be deferred to the kernel.** E820 is
a BIOS interrupt call, and BIOS calls only work in real mode (or via
virtual-8086 mode, which we don't use). This is why memory detection
lives in stage2.S rather than as a "real" driver in the kernel - it's
one of a small number of things that structurally have to happen
before the protected-mode switch.

**Reserve the whole first 1MB rather than precisely tracking what we
occupy.** We could compute exactly which bytes our bootloader, stack,
and kernel use and only reserve those - but that requires the PMM to
know kernel-specific layout details it shouldn't need to care about,
and the savings (recovering a fraction of 1MB out of however much RAM
is available) aren't worth the coupling. This does mean our page
allocator effectively "wastes" up to 1MB of usable RAM by treating it
as permanently reserved - an acceptable and common tradeoff for a
hobby OS at this scale.

**Heap is a single fixed-size arena, not grow-on-demand.** A 1MB heap
is requested once at boot via 256 calls to pmm_alloc_page(), assumed
(not verified) to be contiguous - true in practice at this point in
boot since nothing else has allocated pages yet and the PMM bitmap
scan always returns the lowest free frame first. Documented this
assumption directly in kmalloc.c's file header since it's a latent
correctness dependency that would break silently if boot ordering ever
changes (e.g. if some future driver allocated pages before
`kheap_init()` runs).

### Size budget tracking

| Component  | Actual size | Budget    |
|------------|-------------|-----------|
| boot.bin   | 512 bytes   | 512 (fixed) |
| stage2.bin | 440 bytes   | 8192 (16 sectors) |
| kernel.bin | 7969 bytes  | 51200 (100 sectors) |
| **Total image** | **59904 bytes (~58.5KB)** | **524288 (512KB)** |

stage2 grew 320 -> 440 bytes (E820 detection code). Kernel grew 6401 ->
7969 bytes (PMM + heap allocator + meminfo command). Still very
comfortable headroom against the 512KB target.

### What's verified vs. not

**Verified (statically):** clean build, one GCC warning investigated
and confirmed to be a false positive (see above) rather than an actual
codegen problem; disassembly of the stage2 E820 loop matches the
intended SMAP-call/continuation-check/count-store logic instruction by
instruction; linked kernel symbols (bitmap array, pmm_init) land at
sane, non-overlapping addresses; no undefined symbols in the final
ELF; boot signature and sector budgets all still intact.

**Not yet verified (needs QEMU):** does `meminfo` report a sane total
memory figure (QEMU's default RAM is 128MB, so we'd expect roughly
that minus ~1MB reserved, capped at our 256MB ceiling so it should
report the true value here); does kmalloc/kfree actually work
correctly under real use (nothing exercises them yet beyond the heap's
own initialization - that'll get real exercise once the filesystem
milestone needs dynamic buffers); does the E820 call succeed at all on
this BIOS (SeaBIOS support for E820 is essentially universal, but
worth confirming rather than assuming).

**Status:** Confirmed working in QEMU by the user - meminfo reports
sane numbers. Milestone 4 complete.

**Next steps:** confirm `meminfo` reports sane numbers. Then Milestone
5 (per the original roadmap): persistent storage - a disk-based
filesystem, which is also the first place kmalloc will get real
exercise (file buffers, directory entries, etc.).

---

## Milestone 5: Persistent storage + first applications

**Date:** 2026-08-23

### Scope

- ATA PIO disk driver (kernel/ata.c/h), primary bus, master drive,
  28-bit LBA, multi-sector transfers. Talks to the exact same disk
  image the BIOS boot chain loaded from - QEMU's `-drive` raw image is
  this same device, just accessed via direct port I/O instead of BIOS
  calls (which aren't usable once we're in protected mode).
- ClaudeFS (kernel/fs.c/h): a deliberately simple flat filesystem, no
  directories, no block chaining. Each of 16 file slots maps to a
  fixed, pre-determined location on disk purely by its index in the
  file table - so there's no allocation logic to get wrong. Trade-off:
  max 16 files, max 8KB each, and a deleted file's slot can be reused
  but its raw data isn't wiped (documented as a known limitation, not
  an oversight - no secure delete).
- Filesystem auto-formats on first boot: if the superblock's magic
  number doesn't match, `fs_init()` lays down a fresh one. This means
  the shipped disk image doesn't need a separate `mkfs` step - it just
  needs to reserve the right amount of (zero-filled) disk space, which
  the Makefile now does.
- Shell commands: `ls`, `write <file> <text>`, `cat <file>`, `rm
  <file>` - the required create/read/save/delete/list file operations.
- Notepad app (`notepad <file>`): a line-based editor (append-only,
  `:wq`/`:q` to save or discard) built entirely on the fs API above.
- Calculator app (`calc <a> <op> <b>`): integer +, -, *, / with a
  hand-rolled tokenizer and parser (no `strtok`/`atoi` in freestanding
  C).
- `sysinfo` command combining version, uptime, memory, and filesystem
  info into one view.

### Repo state at the start of this milestone

Similar to Milestone 3: `fs.c`, `fs.h`, and extended `ports.h`/
`kstring.c/h` (with `inw`/`outw`/`io_wait` and `kmemcpy`/`kmemset`)
were already present and fully written when this work began, but
`ata.c/h` (which fs.c depends on) didn't exist yet, and nothing wired
storage into kmain.c or the shell. I read the existing fs.c/fs.h in
full before writing anything - confirming its fixed-slot design,
on-disk layout, and exact expected `ata_read_sectors`/
`ata_write_sectors` function signatures - then wrote ata.c to match
that expected API (initially writing a single-sector-only version
first, which didn't match what fs.c actually called - caught this by
grepping for the actual call sites rather than assuming my first guess
at the API was right, and rewrote to a proper multi-sector interface).

### Bug caught before shipping: duplicate function definitions from parallel edits

Adding `inw`/`outw`/`io_wait` to ports.h and `kmemcpy`/`kmemset` to
kstring.c/h produced "redefinition" compile errors - both were already
defined in those files (from the prior work described above) with
slightly different signatures (mine used `void kmemcpy(...)`, the
existing ones correctly used the standard libc-compatible `void
*kmemcpy(...)` returning the destination pointer). Rather than pick
arbitrarily, I kept the pre-existing libc-compatible signatures (better
practice, matches what any C developer would expect from something
named `kmemcpy`) and removed my duplicates. This is the same class of
issue as Milestone 3's filename collision - working in a codebase with
content from earlier in the session that isn't fully visible turn-to-
turn means duplicate/conflicting additions are a real risk, and the
fix is the same each time: read what's already there before adding,
and let the compiler's error messages point at exactly what collided
when something slips through.

### Verification specifically worth calling out

Two things I checked deliberately rather than trusting arithmetic on
paper, because getting them wrong would corrupt data silently rather
than crash loudly:

1. **The packed `struct file_entry` size.** fs.c's on-disk layout
   depends on this struct being exactly 40 bytes (so 16 files fit in
   exactly 2 sectors, per the Makefile's hardcoded
   `FS_FILE_TABLE_SECTORS`). Rather than trust manual field-width
   addition, I compiled a standalone host-side test program with the
   identical struct definition and printed `sizeof()` - confirmed 40
   bytes exactly, matching the Makefile.

2. **Multi-sector ATA PIO's DRQ-per-sector requirement.** This is a
   classic, easy-to-get-subtly-wrong bug: checking the DRQ (data
   request) status flag once before a multi-sector transfer, then
   reading `count` sectors' worth of words in one uninterrupted loop,
   *works* for `count=1` but silently corrupts data for anything
   larger, because DRQ actually re-asserts once per sector, not once
   for the whole command. I disassembled the compiled
   `ata_read_sectors` and confirmed the DRQ check
   (`test al,0x8` / `jne`) sits inside the per-sector loop body, not
   outside it - the compiler preserved the source's correct structure
   as written, but this was exactly the kind of thing worth confirming
   rather than assuming.

### A note on the 512KB budget's meaning, now that persistent storage exists

The project's "512KB or smaller" goal was written before persistent
storage was in scope, and storage inherently needs disk space that
scales with how much the user actually saves - that can't be bounded
to fit inside a fixed code-size budget. Going forward, "512KB" is
being tracked as the OS's own code size (bootloader + kernel, i.e.
build/boot.bin + build/stage2.bin + build/kernel.bin), separate from
the filesystem's reserved disk region (currently 259 sectors / ~127KB,
itself mostly empty/zero-filled space for user files, not OS code).
The Makefile's `size` target now reports both numbers separately for
clarity. As it happens, the *total* image (OS code + filesystem
region) is still comfortably under 512KB at this milestone (see table
below), but that's not being treated as a hard constraint on the
filesystem region the way it is for the OS code itself.

### Size budget tracking

| Component  | Actual size | Budget    |
|------------|-------------|-----------|
| boot.bin   | 512 bytes   | 512 (fixed) |
| stage2.bin | 440 bytes   | 8192 (16 sectors) |
| kernel.bin | 13185 bytes | 51200 (100 sectors) |
| filesystem region | 132608 bytes (259 sectors) | user-data storage, not code |
| **Total image** | **235008 bytes (~229.5KB)** | **524288 (512KB) - see note above on scope** |

Kernel grew 7969 -> 13185 bytes (ATA driver, filesystem, notepad,
calculator, sysinfo). Still very comfortable headroom for the OS code
itself.

### What's verified vs. not

**Verified (statically):** clean build (aside from the previously-
investigated PMM false-positive warning); no undefined symbols in the
final ELF; boot signature intact; the packed file-table struct's size
matches what the Makefile assumes; disassembly confirms the ATA
driver's DRQ check happens per-sector, not once for the whole
transfer; Makefile correctly reserves and zero-fills the filesystem's
disk region so it's ready for format-on-first-boot.

**Not yet verified (needs QEMU):** does the filesystem actually format
correctly on first boot (magic mismatch -> fresh superblock); do
`write`/`cat`/`rm`/`ls` actually persist data correctly to real disk
I/O (not just compile correctly); critically, **does data survive an
actual reboot** (write a file, `reboot`, `cat` it again) - this is the
entire point of "persistent" storage and the one thing that's
impossible to verify without a real emulator; does `notepad` work
end-to-end (existing content loads and displays, new lines append
correctly, `:wq` actually persists); does `calc` handle basic
expressions and edge cases (division by zero, negative numbers)
correctly.

**Next steps:** confirm the filesystem actually persists data across
reboots - this is the single most important thing to verify at this
milestone, more so than any individual command working. Then remaining
roadmap items: more games/apps (calculator exists in basic form;
Snake, Minesweeper, Blackjack, Pong, Tetris, Tic-Tac-Toe, 2048 are all
still open), and a general optimization/size-tightening pass once the
feature set is more complete.
