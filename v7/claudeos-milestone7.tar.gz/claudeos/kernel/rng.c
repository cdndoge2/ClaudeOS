/*
 * Simple linear congruential generator. Not suitable for anything
 * security-sensitive (predictable, short-ish period, no real entropy
 * source behind the seed) - fine for card shuffling and mine placement,
 * which is all this OS needs it for. Constants are the same ones
 * glibc's rand() historically used (a common, well-tested LCG choice),
 * not something invented here.
 */

#include "rng.h"

static unsigned int state = 1;

void rng_seed(unsigned int seed) {
    state = (seed != 0) ? seed : 1; /* 0 would make every call return 0 */
}

unsigned int rng_next(void) {
    state = state * 1103515245u + 12345u;
    return (state >> 16) & 0x7FFF;
}

unsigned int rng_range(unsigned int max) {
    if (max == 0) {
        return 0;
    }
    return rng_next() % max;
}
