#ifndef CLAUDEOS_KPRINT_H
#define CLAUDEOS_KPRINT_H

void kprint_uint(unsigned int value);
void kprint_int(int value);

#endif
