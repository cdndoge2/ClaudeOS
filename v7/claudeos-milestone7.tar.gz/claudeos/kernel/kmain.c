/*
 * ClaudeOS kernel - kmain
 *
 * Milestone 6 scope: a TUI main menu replacing direct entry into the
 * raw shell. Everything from prior milestones (interrupts, memory,
 * storage, shell, apps) is unchanged - this just adds a menu layer on
 * top and a first game (Tic-Tac-Toe).
 */

#include "vga.h"
#include "idt.h"
#include "isr.h"
#include "irq.h"
#include "pic.h"
#include "pit.h"
#include "keyboard.h"
#include "shell.h"
#include "menu.h"
#include "pmm.h"
#include "kmalloc.h"
#include "fs.h"

void kmain(void) {
    vga_clear();
    vga_print_at("ClaudeOS - Milestone 7: more games", 0, 0);
    vga_print_at("Initializing...", 1, 0);

    idt_install();
    isr_install_all();
    pic_remap();
    irq_install_all();
    keyboard_init();

    __asm__ volatile ("sti");

    pit_init(100);

    pmm_init();
    kheap_init();
    fs_init();

    menu_run();

    /* menu_run() loops forever and should never return, but if it
       somehow does, don't fall off into garbage - halt cleanly. */
    for (;;) {
        __asm__ volatile ("cli; hlt");
    }
}
