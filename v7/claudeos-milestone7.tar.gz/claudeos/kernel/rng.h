#ifndef CLAUDEOS_RNG_H
#define CLAUDEOS_RNG_H

/* Seeds the generator. Callers typically pass pit_get_ticks() so each
   game gets a different sequence depending on how much real time has
   passed since boot - not cryptographically random, not even
   uniformly distributed in any rigorous sense, but entirely adequate
   for shuffling a deck or placing mines in a hobby OS with no other
   entropy source (no RTC driver yet). */
void rng_seed(unsigned int seed);

/* Returns a pseudo-random value in [0, 32767]. */
unsigned int rng_next(void);

/* Returns a pseudo-random value in [0, max) - max must be > 0. */
unsigned int rng_range(unsigned int max);

#endif
