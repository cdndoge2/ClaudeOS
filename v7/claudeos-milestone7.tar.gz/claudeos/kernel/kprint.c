/*
 * Small shared decimal-printing helpers. Originally written as static
 * functions inside shell.c; pulled out here once games needed the same
 * logic too, rather than letting each game file duplicate its own
 * copy - one implementation, used by shell.c and every game module.
 */

#include "kprint.h"
#include "vga.h"

void kprint_uint(unsigned int value) {
    char buf[16];
    int pos = 15;
    buf[pos] = '\0';
    if (value == 0) {
        buf[--pos] = '0';
    } else {
        while (value > 0 && pos > 0) {
            buf[--pos] = (char)('0' + (value % 10));
            value /= 10;
        }
    }
    term_print(&buf[pos]);
}

void kprint_int(int value) {
    if (value < 0) {
        term_print("-");
        kprint_uint((unsigned int)(-value));
    } else {
        kprint_uint((unsigned int)value);
    }
}
