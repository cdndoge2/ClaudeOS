/*
 * 2048 - 4x4 grid, WASD movement (single keypress via
 * keyboard_getchar, no Enter needed - unlike the line-based input the
 * other games/apps use, this one benefits from immediate response per
 * key, and the grid is simple enough that redrawing the whole screen
 * on every move is cheap).
 *
 * Movement algorithm: each of the four directions reduces to the same
 * "slide and merge a line of 4 values toward index 0" operation -
 * left/right operate on rows (right just reverses first), up/down
 * operate on columns (down reverses). Implementing one slide_merge_line
 * function and reusing it via reversal avoids four near-duplicate
 * merge implementations, at the cost of a few array copies that don't
 * matter at this scale (16 cells).
 */

#include "game2048.h"
#include "vga.h"
#include "keyboard.h"
#include "kprint.h"
#include "rng.h"
#include "pit.h"

#define SIZE 4

static unsigned int grid[SIZE][SIZE];

static int spawn_tile(void) {
    int empty_r[SIZE * SIZE], empty_c[SIZE * SIZE];
    int count = 0;

    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) {
            if (grid[r][c] == 0) {
                empty_r[count] = r;
                empty_c[count] = c;
                count++;
            }
        }
    }
    if (count == 0) {
        return 0;
    }

    int pick = (int)rng_range((unsigned int)count);
    grid[empty_r[pick]][empty_c[pick]] = (rng_range(10) == 0) ? 4 : 2;
    return 1;
}

static void reset_game(void) {
    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) {
            grid[r][c] = 0;
        }
    }
    rng_seed(pit_get_ticks());
    spawn_tile();
    spawn_tile();
}

/* Slides non-zero values toward index 0, merging one adjacent equal
   pair per value (standard 2048 rule - a tile can only merge once per
   move). Returns 1 if the line actually changed, so the caller knows
   whether this counted as a real move. */
static int slide_merge_line(unsigned int line[SIZE]) {
    unsigned int original[SIZE];
    for (int i = 0; i < SIZE; i++) original[i] = line[i];

    unsigned int compact[SIZE] = {0, 0, 0, 0};
    int idx = 0;
    for (int i = 0; i < SIZE; i++) {
        if (line[i] != 0) {
            compact[idx++] = line[i];
        }
    }
    for (int i = 0; i < SIZE; i++) line[i] = compact[i];

    for (int i = 0; i < SIZE - 1; i++) {
        if (line[i] != 0 && line[i] == line[i + 1]) {
            line[i] *= 2;
            for (int j = i + 1; j < SIZE - 1; j++) {
                line[j] = line[j + 1];
            }
            line[SIZE - 1] = 0;
        }
    }

    int changed = 0;
    for (int i = 0; i < SIZE; i++) {
        if (line[i] != original[i]) changed = 1;
    }
    return changed;
}

static void reverse_line(unsigned int line[SIZE]) {
    unsigned int tmp = line[0]; line[0] = line[3]; line[3] = tmp;
    tmp = line[1]; line[1] = line[2]; line[2] = tmp;
}

static int move_left(void) {
    int changed = 0;
    for (int r = 0; r < SIZE; r++) {
        changed |= slide_merge_line(grid[r]);
    }
    return changed;
}

static int move_right(void) {
    int changed = 0;
    for (int r = 0; r < SIZE; r++) {
        reverse_line(grid[r]);
        changed |= slide_merge_line(grid[r]);
        reverse_line(grid[r]);
    }
    return changed;
}

static int move_up(void) {
    int changed = 0;
    for (int c = 0; c < SIZE; c++) {
        unsigned int col[SIZE];
        for (int r = 0; r < SIZE; r++) col[r] = grid[r][c];
        changed |= slide_merge_line(col);
        for (int r = 0; r < SIZE; r++) grid[r][c] = col[r];
    }
    return changed;
}

static int move_down(void) {
    int changed = 0;
    for (int c = 0; c < SIZE; c++) {
        unsigned int col[SIZE];
        for (int r = 0; r < SIZE; r++) col[r] = grid[SIZE - 1 - r][c];
        changed |= slide_merge_line(col);
        for (int r = 0; r < SIZE; r++) grid[SIZE - 1 - r][c] = col[r];
    }
    return changed;
}

static int has_won(void) {
    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) {
            if (grid[r][c] >= 2048) return 1;
        }
    }
    return 0;
}

static int can_move(void) {
    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) {
            if (grid[r][c] == 0) return 1;
            if (c < SIZE - 1 && grid[r][c] == grid[r][c + 1]) return 1;
            if (r < SIZE - 1 && grid[r][c] == grid[r + 1][c]) return 1;
        }
    }
    return 0;
}

static int digit_count(unsigned int value) {
    int d = 1;
    while (value >= 10) { value /= 10; d++; }
    return d;
}

static void print_cell(unsigned int value) {
    const int width = 6;
    int len = (value == 0) ? 1 : digit_count(value);
    for (int i = 0; i < width - len; i++) term_print(" ");
    if (value == 0) {
        term_print(".");
    } else {
        kprint_uint(value);
    }
}

static void print_grid(void) {
    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) {
            print_cell(grid[r][c]);
        }
        term_print("\n");
    }
}

static void wait_for_enter(void) {
    term_print("\nPress Enter to return to the menu...");
    char dummy[8];
    keyboard_read_line(dummy, sizeof(dummy));
}

void game_2048(void) {
    reset_game();

    for (;;) {
        term_clear();
        term_print("=== 2048 ===\n");
        term_print("WASD to move, Q to quit\n\n");
        print_grid();

        char key = keyboard_getchar();
        char lower = key;
        if (lower >= 'A' && lower <= 'Z') {
            lower = (char)(lower - 'A' + 'a');
        }

        if (lower == 'q') {
            term_print("\nQuitting.\n");
            wait_for_enter();
            return;
        }

        int changed = 0;
        switch (lower) {
            case 'w': changed = move_up();    break;
            case 's': changed = move_down();  break;
            case 'a': changed = move_left();  break;
            case 'd': changed = move_right(); break;
            default: continue; /* unrecognized key - redraw and wait again */
        }

        if (changed) {
            spawn_tile();

            if (has_won()) {
                term_clear();
                term_print("=== 2048 ===\n\n");
                print_grid();
                term_print("\nYou reached 2048 - you win!\n");
                wait_for_enter();
                return;
            }
            if (!can_move()) {
                term_clear();
                term_print("=== 2048 ===\n\n");
                print_grid();
                term_print("\nNo more moves - game over.\n");
                wait_for_enter();
                return;
            }
        }
    }
}
