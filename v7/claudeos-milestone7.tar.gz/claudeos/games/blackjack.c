/*
 * Blackjack - single player vs. a dealer that hits on 16 and stands
 * on 17, standard ace-flexible scoring.
 *
 * Simplification worth calling out: cards are drawn from an "infinite
 * deck" - each draw is an independent random rank (1-13) with no
 * tracking of which specific cards have already been dealt. A real
 * deck (52 cards, no repeats until reshuffled) would need an array
 * representing the deck plus a shuffle step; that's a reasonable next
 * step if this ever needs to feel more like a real casino game, but
 * an infinite deck is a common, honest simplification for a simple
 * card game and doesn't materially change how the game plays for a
 * single hand at a time.
 *
 * Hand sizes are capped at 32 cards - theoretically a hand of many
 * aces (each countable as low as 1) could exceed 21 total across more
 * cards than any realistic game would produce, so 32 is defensive
 * headroom against a pathological RNG sequence, not a realistic limit.
 */

#include "blackjack.h"
#include "vga.h"
#include "keyboard.h"
#include "kprint.h"
#include "rng.h"
#include "pit.h"

#define MAX_HAND 32

static int draw_card(void) {
    return (int)rng_range(13) + 1; /* 1=Ace, 11=Jack, 12=Queen, 13=King */
}

/* Ace-flexible scoring: count every ace as 1 first, then upgrade as
   many aces as possible to 11 (add 10 each) without busting. This
   naturally produces correct standard blackjack totals without needing
   to track "soft" vs "hard" hands explicitly. */
static int hand_total(const int *cards, int count) {
    int total = 0;
    int aces = 0;

    for (int i = 0; i < count; i++) {
        int rank = cards[i];
        int value = (rank >= 10) ? 10 : rank;
        if (rank == 1) aces++;
        total += value;
    }

    while (aces > 0 && total + 10 <= 21) {
        total += 10;
        aces--;
    }
    return total;
}

static void print_card_name(int rank) {
    switch (rank) {
        case 1:  term_print("A"); break;
        case 11: term_print("J"); break;
        case 12: term_print("Q"); break;
        case 13: term_print("K"); break;
        default: kprint_uint((unsigned int)rank); break;
    }
}

static void print_hand(const char *label, const int *cards, int count, int hide_first) {
    term_print(label);
    term_print(": ");
    for (int i = 0; i < count; i++) {
        if (i == 0 && hide_first) {
            term_print("?? ");
            continue;
        }
        print_card_name(cards[i]);
        term_print(" ");
    }
    if (!hide_first) {
        term_print("(total ");
        kprint_int(hand_total(cards, count));
        term_print(")");
    }
    term_print("\n");
}

static void wait_for_enter(void) {
    term_print("\nPress Enter to return to the menu...");
    char dummy[8];
    keyboard_read_line(dummy, sizeof(dummy));
}

void game_blackjack(void) {
    rng_seed(pit_get_ticks());

    int player[MAX_HAND], player_count = 0;
    int dealer[MAX_HAND], dealer_count = 0;

    player[player_count++] = draw_card();
    dealer[dealer_count++] = draw_card();
    player[player_count++] = draw_card();
    dealer[dealer_count++] = draw_card();

    int player_bust = 0;

    for (;;) {
        term_clear();
        term_print("=== Blackjack ===\n\n");
        print_hand("Dealer", dealer, dealer_count, 1);
        print_hand("You   ", player, player_count, 0);

        if (hand_total(player, player_count) > 21) {
            player_bust = 1;
            break;
        }

        term_print("\n(H)it or (S)tand? ");
        char key = keyboard_getchar();
        char lower = key;
        if (lower >= 'A' && lower <= 'Z') {
            lower = (char)(lower - 'A' + 'a');
        }

        if (lower == 'h') {
            if (player_count < MAX_HAND) {
                player[player_count++] = draw_card();
            }
        } else if (lower == 's') {
            break;
        }
        /* any other key: redraw and ask again */
    }

    if (!player_bust) {
        while (hand_total(dealer, dealer_count) < 17 && dealer_count < MAX_HAND) {
            dealer[dealer_count++] = draw_card();
        }
    }

    term_clear();
    term_print("=== Blackjack ===\n\n");
    print_hand("Dealer", dealer, dealer_count, 0);
    print_hand("You   ", player, player_count, 0);
    term_print("\n");

    if (player_bust) {
        term_print("You busted! Dealer wins.\n");
    } else {
        int player_total = hand_total(player, player_count);
        int dealer_total = hand_total(dealer, dealer_count);

        if (dealer_total > 21) {
            term_print("Dealer busts - you win!\n");
        } else if (player_total > dealer_total) {
            term_print("You win!\n");
        } else if (player_total < dealer_total) {
            term_print("Dealer wins.\n");
        } else {
            term_print("Push (tie).\n");
        }
    }

    wait_for_enter();
}
