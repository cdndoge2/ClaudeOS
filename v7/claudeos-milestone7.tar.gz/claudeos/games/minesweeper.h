#ifndef CLAUDEOS_MINESWEEPER_H
#define CLAUDEOS_MINESWEEPER_H

void game_minesweeper(void);

#endif
