/*
 * Minesweeper - classic 8x8 grid, 10 mines.
 *
 * Input is coordinate-based ("row col action", e.g. "3 4 r" to reveal
 * or "3 4 f" to flag) rather than cursor movement, for the same reason
 * Tic-Tac-Toe uses numpad digits: no cursor-addressed input exists yet
 * in drivers/vga.c, and coordinate entry via the existing line-reading
 * primitive needs no new input infrastructure.
 *
 * Flood-fill reveal (opening all connected zero-adjacent-mine cells
 * when a blank area is uncovered) is implemented recursively - the
 * grid is only 8x8 (64 cells), so worst-case recursion depth is
 * trivial against the kernel's 16KB stack; a real OS with much larger
 * boards or a smaller stack budget would want an explicit stack/queue
 * instead, but that complexity isn't justified here.
 */

#include "minesweeper.h"
#include "vga.h"
#include "keyboard.h"
#include "kstring.h"
#include "kprint.h"
#include "rng.h"
#include "pit.h"

#define GRID_SIZE 8
#define MINE_COUNT 10

struct cell {
    unsigned char is_mine;
    unsigned char revealed;
    unsigned char flagged;
    unsigned char adjacent;
};

static struct cell grid[GRID_SIZE][GRID_SIZE];
static int game_over;
static int hit_mine;

static void place_mines(void) {
    int placed = 0;
    while (placed < MINE_COUNT) {
        int r = (int)rng_range(GRID_SIZE);
        int c = (int)rng_range(GRID_SIZE);
        if (!grid[r][c].is_mine) {
            grid[r][c].is_mine = 1;
            placed++;
        }
    }
}

static int count_adjacent(int r, int c) {
    int count = 0;
    for (int dr = -1; dr <= 1; dr++) {
        for (int dc = -1; dc <= 1; dc++) {
            if (dr == 0 && dc == 0) continue;
            int nr = r + dr, nc = c + dc;
            if (nr >= 0 && nr < GRID_SIZE && nc >= 0 && nc < GRID_SIZE &&
                grid[nr][nc].is_mine) {
                count++;
            }
        }
    }
    return count;
}

static void reset_game(void) {
    for (int r = 0; r < GRID_SIZE; r++) {
        for (int c = 0; c < GRID_SIZE; c++) {
            grid[r][c].is_mine = 0;
            grid[r][c].revealed = 0;
            grid[r][c].flagged = 0;
            grid[r][c].adjacent = 0;
        }
    }
    rng_seed(pit_get_ticks());
    place_mines();
    for (int r = 0; r < GRID_SIZE; r++) {
        for (int c = 0; c < GRID_SIZE; c++) {
            if (!grid[r][c].is_mine) {
                grid[r][c].adjacent = (unsigned char)count_adjacent(r, c);
            }
        }
    }
    game_over = 0;
    hit_mine = 0;
}

static void reveal(int r, int c) {
    if (r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE) return;
    if (grid[r][c].revealed || grid[r][c].flagged) return;

    grid[r][c].revealed = 1;

    if (grid[r][c].is_mine) {
        game_over = 1;
        hit_mine = 1;
        return;
    }

    if (grid[r][c].adjacent == 0) {
        for (int dr = -1; dr <= 1; dr++) {
            for (int dc = -1; dc <= 1; dc++) {
                if (dr == 0 && dc == 0) continue;
                reveal(r + dr, c + dc);
            }
        }
    }
}

static int check_win(void) {
    for (int r = 0; r < GRID_SIZE; r++) {
        for (int c = 0; c < GRID_SIZE; c++) {
            if (!grid[r][c].is_mine && !grid[r][c].revealed) {
                return 0;
            }
        }
    }
    return 1;
}

static void print_grid(int reveal_all) {
    term_print("    ");
    for (int c = 0; c < GRID_SIZE; c++) {
        kprint_uint((unsigned int)c);
        term_print(" ");
    }
    term_print("\n");

    for (int r = 0; r < GRID_SIZE; r++) {
        kprint_uint((unsigned int)r);
        term_print("   ");
        for (int c = 0; c < GRID_SIZE; c++) {
            char ch;
            if (grid[r][c].flagged && !reveal_all) {
                ch = 'F';
            } else if (grid[r][c].revealed || reveal_all) {
                if (grid[r][c].is_mine) {
                    ch = '*';
                } else if (grid[r][c].adjacent == 0) {
                    ch = ' ';
                } else {
                    ch = (char)('0' + grid[r][c].adjacent);
                }
            } else {
                ch = '.';
            }
            char buf[2] = { ch, '\0' };
            term_print(buf);
            term_print(" ");
        }
        term_print("\n");
    }
}

static void wait_for_enter(void) {
    term_print("\nPress Enter to return to the menu...");
    char dummy[8];
    keyboard_read_line(dummy, sizeof(dummy));
}

void game_minesweeper(void) {
    reset_game();

    term_clear();
    term_print("=== Minesweeper === (");
    kprint_uint(GRID_SIZE);
    term_print("x");
    kprint_uint(GRID_SIZE);
    term_print(" grid, ");
    kprint_uint(MINE_COUNT);
    term_print(" mines)\n");
    term_print("Enter: <row> <col> <r|f>  (r = reveal, f = flag)  or 'q' to quit\n\n");

    while (!game_over) {
        print_grid(0);
        term_print("\n> ");

        char line[32];
        keyboard_read_line(line, sizeof(line));

        if (kstrcmp(line, "q") == 0) {
            term_print("\nQuitting.\n");
            wait_for_enter();
            return;
        }

        int i = 0;
        while (line[i] == ' ') i++;
        int r_start = i;
        while (line[i] != '\0' && line[i] != ' ') i++;
        int r_len = i - r_start;

        while (line[i] == ' ') i++;
        int c_start = i;
        while (line[i] != '\0' && line[i] != ' ') i++;
        int c_len = i - c_start;

        while (line[i] == ' ') i++;
        char action = line[i];

        if (r_len == 0 || r_len > 1 || c_len == 0 || c_len > 1 ||
            (action != 'r' && action != 'f')) {
            term_print("\nInvalid input. Format: <row> <col> <r|f>\n\n");
            continue;
        }

        int row = line[r_start] - '0';
        int col = line[c_start] - '0';
        if (row < 0 || row >= GRID_SIZE || col < 0 || col >= GRID_SIZE) {
            term_print("\nRow/col out of range (0-");
            kprint_uint(GRID_SIZE - 1);
            term_print(").\n\n");
            continue;
        }

        term_clear();
        term_print("=== Minesweeper ===\n\n");

        if (action == 'f') {
            grid[row][col].flagged = !grid[row][col].flagged;
        } else {
            reveal(row, col);
        }

        if (!game_over && check_win()) {
            game_over = 1;
        }
    }

    print_grid(1);
    if (hit_mine) {
        term_print("\nBOOM! You hit a mine. Game over.\n");
    } else {
        term_print("\nAll clear - you win!\n");
    }
    wait_for_enter();
}
