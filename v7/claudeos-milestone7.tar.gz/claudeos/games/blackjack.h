#ifndef CLAUDEOS_BLACKJACK_H
#define CLAUDEOS_BLACKJACK_H

void game_blackjack(void);

#endif
