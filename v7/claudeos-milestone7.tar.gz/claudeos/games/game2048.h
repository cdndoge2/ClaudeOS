#ifndef CLAUDEOS_GAME2048_H
#define CLAUDEOS_GAME2048_H

void game_2048(void);

#endif
